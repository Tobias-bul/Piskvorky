/* Piškvorky Trenér – aplikace */
(function () {
  'use strict';
  var N = 15, NN = 225;
  var $ = function (s) { return document.querySelector(s); };
  var $$ = function (s) { return Array.prototype.slice.call(document.querySelectorAll(s)); };

  // ---------------- nastavení ----------------
  var DEFAULTS = {
    confirmMove: true, coords: true, numbers: false, lastMove: true, hints: true, undo: true,
    threats: false, stats: false, analysis: true, light: false, botDelay: true,
    opening: 'classic', level: 3, rule: 'free', role: 'x', swapRole: 'opener'
  };
  var S = {};
  function loadSettings() {
    try { S = Object.assign({}, DEFAULTS, JSON.parse(localStorage.getItem('pq_settings') || '{}')); }
    catch (e) { S = Object.assign({}, DEFAULTS); }
  }
  function saveSettings() { try { localStorage.setItem('pq_settings', JSON.stringify(S)); } catch (e) {} }
  function loadJSON(k, d) { try { return JSON.parse(localStorage.getItem(k)) || d; } catch (e) { return d; } }
  function saveJSON(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }

  // ---------------- engine (worker) ----------------
  var Engine = (function () {
    var worker = null, worker2 = null, seq = 0, pending = {}, direct = null;
    try {
      var src = EngineModule.toString() + '\n(' + engineWorkerMain.toString() + ')();';
      var url = URL.createObjectURL(new Blob([src], { type: 'application/javascript' }));
      var onmsg = function (ev) {
        var m = ev.data, cb = pending[m.id];
        if (!cb) return; delete pending[m.id];
        if (m.error) { console.error(m.error); cb.reject(m.error); } else cb.resolve(m.result);
      };
      worker = new Worker(url); worker.onmessage = onmsg;
      worker.onerror = function (e) { console.error('worker', e); };
      try { worker2 = new Worker(url); worker2.onmessage = onmsg; } catch (e2) { worker2 = null; }
    } catch (e) { worker = null; }
    window.__engineMode = worker ? 'worker' : 'direct';
    function callDirect(msg) {
      if (!direct) direct = EngineModule();
      var E = direct;
      switch (msg.cmd) {
        case 'move': return E.chooseMove(msg.board, msg.me, msg.level, msg.exact);
        case 'eval': return E.evalPosition(msg.board, msg.toMove, msg.exact, msg.ms);
        case 'checkAttack': return E.checkAttack(msg.board, msg.move, msg.att, msg.exact, msg.mode);
        case 'checkDefense': return E.checkDefense(msg.board, msg.move, msg.def, msg.exact, msg.useVct);
        case 'solve': return E.solve(msg.board, msg.att, msg.exact, msg.mode);
        case 'threats': return E.threatInfo(msg.board, msg.exact);
        case 'opening': return E.makeOpening(msg.exact);
        case 'balance2': return E.balance2(msg.board, msg.exact);
        case 'analyze': return E.analyzeMove(msg.board, msg.move, msg.me, msg.exact);
      }
    }
    function call(cmd, data) {
      var msg = Object.assign({ cmd: cmd }, data);
      if (msg.board) msg.board = Array.prototype.slice.call(msg.board);
      return new Promise(function (resolve, reject) {
        if (!worker) {
          setTimeout(function () { try { resolve(callDirect(msg)); } catch (e) { reject(e); } }, 30);
          return;
        }
        msg.id = ++seq;
        pending[msg.id] = { resolve: resolve, reject: reject };
        ((cmd === 'analyze' && worker2) ? worker2 : worker).postMessage(msg);
      });
    }
    return { call: call };
  })();
  var localE = EngineModule(); // pro rychlé synchronní věci (výherní řada)

  // ---------------- pomocné ----------------
  var LETTERS = 'ABCDEFGHIJKLMNO';
  function cname(p) { return LETTERS[p % N] + (N - ((p / N) | 0)); }
  function parseC(s) { s = s.trim().toUpperCase(); var x = LETTERS.indexOf(s[0]); var r = parseInt(s.slice(1), 10); return (N - r) * N + x; }
  function sym(c) { return c === 1 ? '<b class="x">✕</b>' : '<b class="o">◯</b>'; }
  function wait(ms) { return new Promise(function (r) { setTimeout(r, ms); }); }
  function toast(msg, ms) {
    var t = $('#toast'); t.innerHTML = msg; t.classList.remove('hidden');
    clearTimeout(toast._t); toast._t = setTimeout(function () { t.classList.add('hidden'); }, ms || 2200);
  }
  function modal(title, body, buttons, closable) {
    $('#modal-title').innerHTML = title; $('#modal-body').innerHTML = body || '';
    var bb = $('#modal-buttons'); bb.innerHTML = '';
    (buttons || []).forEach(function (b) {
      var el = document.createElement('button'); el.innerHTML = b.label;
      if (b.primary) el.className = 'primary';
      el.onclick = function () { if (!b.keep) closeModal(); if (b.fn) b.fn(); };
      bb.appendChild(el);
    });
    $('#modal').classList.remove('hidden');
    modal.closable = closable !== false;
  }
  function closeModal() { $('#modal').classList.add('hidden'); }
  $('#modal').addEventListener('click', function (e) { if (e.target.id === 'modal' && modal.closable) closeModal(); });

  // ---------------- navigace ----------------
  var stack = ['menu'];
  function show(id) {
    $$('.screen').forEach(function (s) { s.classList.remove('active'); });
    $('#scr-' + id).classList.add('active');
    if (id === 'game') setTimeout(resizeBoard, 0);
  }
  function go(id) { stack.push(id); show(id); }
  function back() {
    if (!$('#modal').classList.contains('hidden')) { if (modal.closable) closeModal(); return true; }
    if (stack.length <= 1) return false;
    var cur = stack.pop();
    if (cur === 'game') { G.token++; LS = null; }
    show(stack[stack.length - 1]);
    if (stack[stack.length - 1] === 'learn') renderLearnList();
    return true;
  }
  window.handleBack = function () { return back(); };
  $$('[data-back]').forEach(function (b) { b.onclick = back; });
  $$('[data-go]').forEach(function (b) {
    b.onclick = function () {
      var g = b.getAttribute('data-go');
      if (g === 'setup-bot') openSetup('bot');
      else if (g === 'setup-pvp') openSetup('pvp');
      else if (g === 'learn') { renderLearnList(); go('learn'); }
      else if (g === 'settings') { renderSettings(); go('settings'); }
      else if (g === 'stats') { renderStats(); go('stats'); }
    };
  });

  // ---------------- nastavení hry (setup) ----------------
  var setupMode = 'bot';
  var OPENING_NOTES = {
    classic: 'Křížek (✕) začíná a hráči se střídají. Pozor: v čistém gomoku má začínající hráč velkou výhodu.',
    swap1: 'Zakládající položí 3 kameny (✕, ◯, ✕). Druhý hráč si pak vybere barvu. Na tahu je ◯.',
    swap2: 'Zakládající položí 3 kameny (✕, ◯, ✕). Druhý hráč: vezme ✕, vezme ◯, nebo položí další 2 kameny (◯, ✕) a výběr barvy přenechá zakládajícímu. Soutěžní standard.'
  };
  function segSelect(container, val) {
    $$(container + ' button').forEach(function (b) { b.classList.toggle('sel', b.getAttribute('data-v') === String(val)); });
  }
  function renderRoleOpts() {
    var el = $('#opt-role');
    if (S.opening === 'classic') {
      $('#lbl-role').textContent = 'Hraju za';
      el.innerHTML = '<button data-v="x">✕ (začínám)</button><button data-v="o">◯</button><button data-v="rnd">Náhodně</button>';
      segSelect('#opt-role', S.role);
      $$('#opt-role button').forEach(function (b) { b.onclick = function () { S.role = b.getAttribute('data-v'); saveSettings(); segSelect('#opt-role', S.role); }; });
    } else {
      $('#lbl-role').textContent = 'Kdo zakládá (pokládá první 3 kameny)';
      el.innerHTML = '<button data-v="opener">Já</button><button data-v="chooser">Bot</button><button data-v="rnd">Náhodně</button>';
      segSelect('#opt-role', S.swapRole);
      $$('#opt-role button').forEach(function (b) { b.onclick = function () { S.swapRole = b.getAttribute('data-v'); saveSettings(); segSelect('#opt-role', S.swapRole); }; });
    }
  }
  function openSetup(mode) {
    setupMode = mode;
    $('#setup-title').textContent = mode === 'bot' ? 'Hra proti botovi' : 'Dva hráči';
    $$('.bot-only').forEach(function (e) { e.classList.toggle('hidden', mode !== 'bot'); });
    segSelect('#opt-opening', S.opening); segSelect('#opt-level', S.level); segSelect('#opt-rule', S.rule);
    $('#opening-note').textContent = OPENING_NOTES[S.opening];
    renderRoleOpts();
    go('setup');
  }
  $$('#opt-opening button').forEach(function (b) {
    b.onclick = function () { S.opening = b.getAttribute('data-v'); saveSettings(); segSelect('#opt-opening', S.opening); $('#opening-note').textContent = OPENING_NOTES[S.opening]; renderRoleOpts(); };
  });
  $$('#opt-level button').forEach(function (b) { b.onclick = function () { S.level = +b.getAttribute('data-v'); saveSettings(); segSelect('#opt-level', S.level); }; });
  $$('#opt-rule button').forEach(function (b) { b.onclick = function () { S.rule = b.getAttribute('data-v'); saveSettings(); segSelect('#opt-rule', S.rule); }; });
  $('#btn-start').onclick = function () { stack.pop(); startGame({ mode: setupMode }); go('game'); };

  // ---------------- hra ----------------
  // A = zakládající (v klasice = ✕), B = druhý
  var G = { token: 0 };
  var LS = null; // stav lekce
  var LEVEL_NAMES = ['', 'Začátečník', 'Lehký', 'Střední', 'Těžký', 'Expert', 'Neporazitelný'];

  function startGame(opts) {
    LS = null;
    G = {
      token: (G.token || 0) + 1, gid: Math.random(), mode: opts.mode, opening: S.opening, level: S.level, exact: S.rule === 'exact',
      board: new Int8Array(NN), moves: [], phase: 'play', who: { A: 'human', B: 'human' }, colorOf: { A: 1, B: 2 },
      openLen: 0, pending: -1, hint: -1, winLine: null, over: false, busy: false, marks: {}, threats: null, evals: {}, sel: -1, showAlt: false
    };
    if (G.mode === 'bot') {
      if (G.opening === 'classic') {
        var r = S.role === 'rnd' ? (Math.random() < 0.5 ? 'x' : 'o') : S.role;
        G.who = r === 'x' ? { A: 'human', B: 'bot' } : { A: 'bot', B: 'human' };
      } else {
        var sr = S.swapRole === 'rnd' ? (Math.random() < 0.5 ? 'opener' : 'chooser') : S.swapRole;
        G.who = sr === 'opener' ? { A: 'human', B: 'bot' } : { A: 'bot', B: 'human' };
      }
    }
    G.opts = opts;
    if (opts.start) {
      // hra z připravené pozice (schéma)
      G.opening = 'classic'; G.exact = opts.rule === 'exact'; G.level = opts.level || 6;
      G.who = { A: 'human', B: 'bot' }; G.colorOf = { A: opts.human, B: 3 - opts.human };
      (opts.start.x || []).forEach(function (c) { var q = parseC(c); G.board[q] = 1; G.moves.push({ p: q, c: 1 }); });
      (opts.start.o || []).forEach(function (c) { var q = parseC(c); G.board[q] = 2; G.moves.push({ p: q, c: 2 }); });
      G.openLen = G.moves.length;
    } else if (G.opening !== 'classic') { G.phase = 'open3'; G.colorOf = { A: 0, B: 0 }; }
    $('#game-title').textContent = opts.start ? ('Schéma vs ' + LEVEL_NAMES[G.level]) : (G.mode === 'bot' ? ('Bot: ' + LEVEL_NAMES[G.level]) : 'Dva hráči');
    $('#game-toolbar').classList.remove('hidden');
    $('#lesson-toolbar').classList.add('hidden');
    $('#lesson-text').classList.add('hidden');
    $('#btn-hint').classList.toggle('hidden', !S.hints);
    $('#btn-undo').classList.toggle('hidden', !S.undo);
    G.startedAt = Date.now();
    renderAnalysis();
    draw(); updateStatus(); step();
  }

  function countStones(b) { var x = 0, o = 0; for (var i = 0; i < NN; i++) { if (b[i] === 1) x++; else if (b[i] === 2) o++; } return [x, o]; }
  function toMove() { var c = countStones(G.board); return c[0] === c[1] ? 1 : 2; }
  function ownerOfColor(c) { return G.colorOf.A === c ? 'A' : 'B'; }
  function actor() { // kdo je teď na řadě (A/B)
    switch (G.phase) {
      case 'open3': return 'A';
      case 'choose1': return 'B';
      case 'open2': return 'B';
      case 'choose2': return 'A';
      case 'play': return ownerOfColor(toMove());
    }
    return null;
  }
  function openingColor() { // barva dalšího kamene během zakládání
    if (G.phase === 'open3') return [1, 2, 1][G.moves.length];
    if (G.phase === 'open2') return [2, 1][G.moves.length - 3];
    return toMove();
  }
  function playerName(side) {
    if (G.mode === 'bot') return G.who[side] === 'human' ? 'Ty' : 'Bot';
    return side === 'A' ? 'Hráč 1' : 'Hráč 2';
  }
  function updateStatus(extra) {
    var st = $('#status');
    if (LS) return;
    var h = '';
    if (G.over) {
      h = G.result === 'draw' ? 'Remíza – deska je plná.' : (sym(G.result) + ' vyhrál' + (G.mode === 'bot' ? (G.who[ownerOfColor(G.result)] === 'human' ? ' – <b>vyhrál jsi!</b>' : ' – vyhrál bot.') : ' – ' + playerName(ownerOfColor(G.result)) + '.'));
    } else {
      var a = actor(), name = playerName(a);
      var busy = G.mode === 'bot' && G.who[a] === 'bot';
      if (G.phase === 'open3') h = name + ': zakládání – polož ' + sym(openingColor()) + ' (' + (G.moves.length + 1) + '/3)';
      else if (G.phase === 'open2') h = name + ': polož ' + sym(openingColor()) + ' (' + (G.moves.length - 2) + '/2)';
      else if (G.phase === 'choose1' || G.phase === 'choose2') h = name + ': výběr barvy…';
      else {
        h = 'Na tahu: ' + sym(toMove()) + ' ' + name;
        if (G.mode === 'pvp' || G.opening !== 'classic') h += ' <span class="pos">· ✕ = ' + playerName(ownerOfColor(1)) + '</span>';
      }
      if (busy) h = '<span class="spinner"></span> ' + h.replace(name + ':', 'Bot přemýšlí:');
    }
    if (extra) h += ' ' + extra;
    st.innerHTML = h;
    $('#btn-undo').disabled = !canUndo();
    $('#btn-hint').disabled = !(G.phase === 'play' && !G.over && isHumanTurn());
  }
  function isHumanTurn() { var a = actor(); return a && (G.mode === 'pvp' || G.who[a] === 'human'); }

  function placeStone(p, c) {
    G.board[p] = c; G.moves.push({ p: p, c: c }); G.pending = -1; G.hint = -1; G.marks = {};
    if (G.phase === 'play') {
      var wl = localE.winLine(G.board, p, G.exact);
      if (wl) { G.winLine = wl; finish(c); return; }
      var full = true; for (var i = 0; i < NN; i++) if (!G.board[i]) { full = false; break; }
      if (full) { finish('draw'); return; }
    } else if (G.phase === 'open3' && G.moves.length === 3) { G.phase = 'choose1'; G.openLen = 3; }
    else if (G.phase === 'open2' && G.moves.length === 5) { G.phase = 'choose2'; G.openLen = 5; }
  }
  function finish(res) {
    G.over = true; G.result = res;
    draw(); updateStatus();
    recordStats(res);
    var title, body = summaryHtml();
    if (res === 'draw') title = 'Remíza';
    else if (G.mode === 'bot') title = G.who[ownerOfColor(res)] === 'human' ? '🎉 Vyhrál jsi!' : 'Prohra';
    else title = playerName(ownerOfColor(res)) + ' (' + (res === 1 ? '✕' : '◯') + ') vyhrál!';
    setTimeout(function () {
      if (!G.over) return;
      modal(title, body, [
        { label: G.opts && G.opts.start ? 'Znovu stejné schéma' : 'Nová hra', primary: true, fn: function () { startGame(G.opts || { mode: G.mode }); } },
        G.opts && G.opts.start ? { label: 'Zpět do lekce', fn: function () { back(); } } : { label: 'Odveta (prohodit role)', fn: function () { swapRolesAndRestart(); } },
        { label: 'Prohlédnout desku', fn: function () {} }
      ]);
    }, 700);
  }
  function swapRolesAndRestart() {
    if (G.mode === 'bot') {
      if (S.opening === 'classic') S.role = G.who.A === 'human' ? 'o' : 'x';
      else S.swapRole = G.who.A === 'human' ? 'chooser' : 'opener';
      saveSettings();
    }
    startGame({ mode: G.mode });
  }
  function recordStats(res) {
    if (!S.stats || G.mode !== 'bot' || res === undefined) return;
    var st = loadJSON('pq_stats', {});
    var k = 'L' + G.level; st[k] = st[k] || { w: 0, l: 0, d: 0 };
    if (res === 'draw') st[k].d++;
    else if (G.who[ownerOfColor(res)] === 'human') st[k].w++; else st[k].l++;
    saveJSON('pq_stats', st);
  }

  // ---------- hodnocení tahů ----------
  var LABEL_CLS = { '!!': 'b-br', '!': 'b-gr', '★': 'b-best', '✓': 'b-ok', '•': 'b-n', '?!': 'b-in', '?': 'b-mi', '??': 'b-bl' };
  var LABEL_COL = { '!!': '#26c6da', '!': '#3ccf7a', '★': '#3ccf7a', '?!': '#f6c343', '?': '#ff9f43', '??': '#ff5d5d' };
  function requestAnalysis(before, p, c, idx) {
    if (!S.analysis) return;
    var gid = G.gid;
    G.evals[idx] = { pending: true, move: p, c: c };
    G.sel = idx; G.showAlt = false; renderAnalysis();
    Engine.call('analyze', { board: before, move: p, me: c, exact: G.exact }).then(function (r) {
      if (G.gid !== gid || !G.moves[idx] || G.moves[idx].p !== p || !G.evals[idx]) return;
      r.c = c; G.evals[idx] = r;
      renderAnalysis(); draw();
    }).catch(function () { delete G.evals[idx]; renderAnalysis(); });
  }
  function renderAnalysis() {
    var el = $('#analysis');
    if (!el) return;
    var on = S.analysis && !LS && G.mode;
    el.classList.toggle('hidden', !on);
    if (!on) return;
    var e = G.sel >= 0 ? G.evals[G.sel] : null;
    if (!e) { el.innerHTML = '<span class="pos">Hodnocení tahů: zahraj tah a engine ho ohodnotí. Ťuknutím na kámen zobrazíš hodnocení staršího tahu.</span>'; return; }
    if (e.pending) { el.innerHTML = '<span class="spinner"></span> Hodnotím tah ' + cname(e.move) + '…'; return; }
    var h = '<div class="an-head"><span class="badge ' + (LABEL_CLS[e.label] || '') + '">' + e.label + '</span> <b>' + (G.sel + 1) + '. ' + cname(e.move) + ' – ' + e.name + '</b></div>';
    h += '<div>' + e.text + '</div>';
    if (e.best >= 0) {
      h += '<div class="an-alt">Lepší: <b>' + cname(e.best) + '</b>' + (e.alt ? ' – ' + e.alt : '') + ' <button id="btn-alt" class="mini">' + (G.showAlt ? 'Skrýt' : 'Ukázat') + '</button></div>';
    }
    el.innerHTML = h;
    var b = $('#btn-alt'); if (b) b.onclick = function () { G.showAlt = !G.showAlt; renderAnalysis(); draw(); };
  }
  function summaryHtml() {
    if (!S.analysis) return '';
    var cnt = {}, any = false;
    Object.keys(G.evals).forEach(function (k) {
      var e = G.evals[k]; if (!e || e.pending) return;
      if (G.mode === 'bot' && G.who[ownerOfColor(e.c)] !== 'human') return;
      cnt[e.label] = (cnt[e.label] || 0) + 1; any = true;
    });
    if (!any) return '';
    var order = ['!!', '!', '★', '✓', '?!', '?', '??'];
    return '<div class="sum">' + order.filter(function (l) { return cnt[l]; }).map(function (l) { return '<span class="badge ' + LABEL_CLS[l] + '">' + l + '</span> ' + cnt[l] + '×'; }).join(' &nbsp; ') + '</div><span class="pos">Ťuknutím na kameny si projdeš hodnocení jednotlivých tahů.</span>';
  }

  function canUndo() {
    if (!S.undo || G.phase !== 'play' || LS) return false;
    if (G.mode === 'bot') {
      // musí zbýt aspoň jeden lidský tah po zahájení
      for (var i = G.moves.length - 1; i >= G.openLen; i--) if (G.who[ownerOfColor(G.moves[i].c)] === 'human') return true;
      return false;
    }
    return G.moves.length > G.openLen;
  }
  function undo() {
    if (!canUndo()) return;
    G.token++; G.busy = false;
    if (G.over) { G.over = false; G.winLine = null; }
    if (G.mode === 'bot') {
      while (G.moves.length > G.openLen) {
        var m = G.moves.pop(); G.board[m.p] = 0;
        if (G.who[ownerOfColor(m.c)] === 'human') break;
      }
    } else { var m2 = G.moves.pop(); G.board[m2.p] = 0; }
    G.pending = -1; G.hint = -1; G.marks = {};
    Object.keys(G.evals).forEach(function (k) { if (+k >= G.moves.length) delete G.evals[k]; });
    G.sel = -1; G.showAlt = false; renderAnalysis();
    draw(); updateStatus(); step();
  }

  // hlavní smyčka – zajistí tahy bota a dialogy výběru barvy
  function step() {
    if (G.over || LS) return;
    var a = actor();
    if (!a) return;
    var bot = G.mode === 'bot' && G.who[a] === 'bot';
    if (G.phase === 'choose1' || G.phase === 'choose2') {
      if (bot) botChoose(); else humanChoose();
      return;
    }
    updateThreats();
    if (bot) botMove();
  }
  function humanChoose() {
    var a = actor(), name = playerName(a);
    var btns = [
      { label: 'Hraju za ✕', fn: function () { setColors(a, 1); } },
      { label: 'Hraju za ◯ (◯ je na tahu)', fn: function () { setColors(a, 2); } }
    ];
    if (G.phase === 'choose1' && G.opening === 'swap2') btns.push({ label: 'Položit další 2 kameny (◯, ✕)', fn: function () { G.phase = 'open2'; draw(); updateStatus(); step(); } });
    var who = G.mode === 'pvp' ? name + ', vyber si:' : 'Vyber si:';
    setTimeout(function () { modal('Výběr barvy', who + '<br><span class="pos">Prohlédni si desku – modal můžeš zavřít a otevřít znovu tlačítkem ⋯.</span>', btns, true); }, 300);
  }
  function setColors(side, color) {
    var other = side === 'A' ? 'B' : 'A';
    G.colorOf[side] = color; G.colorOf[other] = 3 - color;
    G.phase = 'play';
    draw(); updateStatus();
    var msg = playerName(ownerOfColor(1)) + ' = ✕, ' + playerName(ownerOfColor(2)) + ' = ◯';
    toast(msg);
    step();
  }
  function botChoose() {
    var tok = G.token; G.busy = true; updateStatus();
    var exact = G.exact;
    Engine.call('eval', { board: G.board, toMove: 2, exact: exact, ms: 900 }).then(function (sc) {
      if (tok !== G.token) return;
      G.busy = false;
      var a = actor();
      if (G.phase === 'choose1' && G.opening === 'swap2' && Math.abs(sc) < 250) {
        G.phase = 'open2'; updateStatus();
        toast('Bot volí: položí další 2 kameny');
        G.busy = true;
        Engine.call('balance2', { board: G.board, exact: exact }).then(function (two) {
          if (tok !== G.token) return;
          G.busy = false;
          if (!two) two = randomEmptyNear(2);
          placeStone(two[0], 2); draw();
          setTimeout(function () { if (tok !== G.token) return; placeStone(two[1], 1); draw(); updateStatus(); step(); }, 500);
        });
        return;
      }
      var color = sc > 0 ? 2 : 1;
      toast('Bot si vybral ' + (color === 1 ? '✕' : '◯'));
      setColors(a, color);
    });
  }
  function randomEmptyNear(k) {
    var r = [];
    while (r.length < k) { var p = (5 + ((Math.random() * 5) | 0)) * N + 5 + ((Math.random() * 5) | 0); if (!G.board[p] && r.indexOf(p) < 0) r.push(p); }
    return r;
  }
  function botMove() {
    var tok = G.token; G.busy = true; updateStatus();
    var t0 = Date.now();
    var pr;
    if (G.phase === 'open3') {
      pr = Engine.call('opening', { exact: G.exact }).then(function (op) {
        if (tok !== G.token) return;
        var i = 0;
        (function next() {
          if (tok !== G.token) return;
          placeStone(op[i], [1, 2, 1][i]); draw(); updateStatus(); i++;
          if (i < 3) setTimeout(next, 450); else { G.busy = false; updateStatus(); step(); }
        })();
      });
      return;
    }
    if (G.phase === 'open2') return; // řeší botChoose
    var me = toMove();
    Engine.call('move', { board: G.board, me: me, level: G.level, exact: G.exact }).then(function (r) {
      if (tok !== G.token) return;
      var delay = S.botDelay ? Math.max(0, 350 - (Date.now() - t0)) : 0;
      setTimeout(function () {
        if (tok !== G.token) return;
        G.busy = false;
        if (r.move < 0 || G.board[r.move]) { finish('draw'); return; }
        placeStone(r.move, me); draw(); updateStatus(); step();
      }, delay);
    }).catch(function (e) { G.busy = false; toast('Chyba bota: ' + e); });
  }
  function updateThreats() {
    if (!S.threats || G.phase !== 'play' || G.over) { G.threats = null; return; }
    var tok = G.token, mv = G.moves.length;
    Engine.call('threats', { board: G.board, exact: G.exact }).then(function (t) {
      if (tok !== G.token || mv !== G.moves.length) return;
      G.threats = t; draw();
    });
  }

  function humanTap(p) {
    if (LS) { lessonTap(p); return; }
    if (G.board[p]) {
      for (var mi = G.moves.length - 1; mi >= 0; mi--) if (G.moves[mi].p === p) {
        if (G.evals[mi]) { G.sel = mi; G.showAlt = false; renderAnalysis(); draw(); }
        break;
      }
      return;
    }
    if (G.over || G.busy || !isHumanTurn()) return;
    if (G.phase === 'choose1' || G.phase === 'choose2') { humanChoose(); return; }
    if (G.board[p]) return;
    if (S.confirmMove && G.pending !== p) { G.pending = p; draw(); $('#btn-confirm').classList.remove('hidden'); return; }
    commitHuman(p);
  }
  function commitHuman(p) {
    $('#btn-confirm').classList.add('hidden');
    G.pending = -1;
    var c = G.phase === 'play' ? toMove() : openingColor();
    var wasPlay = G.phase === 'play', before = G.board.slice(), idx = G.moves.length;
    placeStone(p, c);
    if (wasPlay) requestAnalysis(before, p, c, idx);
    draw(); updateStatus(); step();
  }
  $('#btn-confirm').onclick = function () {
    if (LS) { if (LS.pending >= 0) { var p = LS.pending; LS.pending = -1; $('#btn-confirm').classList.add('hidden'); if (LS.line) lineTap(p); else lessonCommit(p); } return; }
    if (G.pending >= 0) commitHuman(G.pending);
  };
  $('#btn-undo').onclick = undo;
  $('#btn-new').onclick = function () {
    if (G.over || G.moves.length <= G.openLen) { startGame(G.opts || { mode: G.mode }); return; }
    modal('Nová hra?', 'Rozehraná partie se ukončí.', [
      { label: 'Ano, nová hra', primary: true, fn: function () { startGame(G.opts || { mode: G.mode }); } },
      { label: 'Nastavení hry', fn: function () { G.token++; stack.pop(); openSetup(G.mode); } },
      { label: 'Zrušit' }]);
  };
  $('#btn-hint').onclick = function () {
    if (!isHumanTurn() || G.phase !== 'play' || G.over) return;
    var tok = G.token; G.busy = true; updateStatus('· hledám nápovědu…');
    Engine.call('move', { board: G.board, me: toMove(), level: 5, exact: G.exact }).then(function (r) {
      if (tok !== G.token) return;
      G.busy = false; G.hint = r.move; draw(); updateStatus();
      var why = { five: 'Pětka!', block: 'Musíš blokovat čtyřku.', open4: 'Otevřená čtyřka vyhrává.', vcf: 'Máš vítězné VCF (série čtyřek)!', vct: 'Máš vítěznou sérii hrozeb (VCT)!' }[r.info] || 'Doporučený tah';
      toast('💡 ' + cname(r.move) + ' – ' + why, 3000);
    });
  };
  $('#btn-gmenu').onclick = function () {
    if (LS) { lessonMenu(); return; }
    var btns = [];
    if (!G.over && (G.phase === 'choose1' || G.phase === 'choose2') && isHumanTurn()) btns.push({ label: 'Vybrat barvu', primary: true, fn: humanChoose });
    btns.push({ label: 'Nová hra', fn: function () { startGame({ mode: G.mode }); } });
    btns.push({ label: 'Nastavení hry', fn: function () { G.token++; stack.pop(); openSetup(G.mode); } });
    btns.push({ label: (S.threats ? 'Skrýt' : 'Zobrazit') + ' hrozby na desce', fn: function () { S.threats = !S.threats; saveSettings(); updateThreats(); draw(); } });
    btns.push({ label: 'Zavřít' });
    var info = 'Zahájení: <b>' + ({ classic: 'klasické', swap1: 'Swap1', swap2: 'Swap2' })[G.opening] + '</b>, pravidlo: <b>' + (G.exact ? 'přesně 5' : '5 a více') + '</b>';
    if (G.phase === 'play') info += '<br>' + playerName(ownerOfColor(1)) + ' = ✕, ' + playerName(ownerOfColor(2)) + ' = ◯';
    modal('Hra', info, btns);
  };

  // ---------------- kreslení desky ----------------
  var canvas = $('#board'), ctx = canvas.getContext('2d');
  var geo = { size: 300, cell: 20, off: 0, dpr: 1 };
  function resizeBoard() {
    var wrap = $('#board-wrap');
    var scr = $('#scr-game');
    var w = scr.clientWidth - 12;
    var hdr = scr.querySelector('header').offsetHeight + $('#status').offsetHeight;
    var tb = (LS ? $('#lesson-toolbar') : $('#game-toolbar')).offsetHeight;
    var minText = LS ? 150 : (S.analysis ? 96 : 0);
    var h = scr.clientHeight - hdr - tb - minText - 16;
    var size = Math.max(200, Math.min(w, h, 720));
    var dpr = window.devicePixelRatio || 1;
    canvas.style.width = size + 'px'; canvas.style.height = size + 'px';
    canvas.width = Math.round(size * dpr); canvas.height = Math.round(size * dpr);
    var showC = S.coords;
    var off = showC ? size * 0.055 : 0;
    geo = { size: size, off: off, cell: (size - off - 2) / N, dpr: dpr };
    draw();
  }
  window.addEventListener('resize', resizeBoard);
  function cellXY(p) { return [geo.off + (p % N) * geo.cell, geo.off + ((p / N) | 0) * geo.cell]; }
  function drawX(x, y, c, color, alpha) {
    var m = c * 0.22;
    ctx.globalAlpha = alpha || 1; ctx.strokeStyle = color; ctx.lineWidth = Math.max(2, c * 0.13); ctx.lineCap = 'round';
    ctx.beginPath(); ctx.moveTo(x + m, y + m); ctx.lineTo(x + c - m, y + c - m); ctx.moveTo(x + c - m, y + m); ctx.lineTo(x + m, y + c - m); ctx.stroke();
    ctx.globalAlpha = 1;
  }
  function drawO(x, y, c, color, alpha) {
    ctx.globalAlpha = alpha || 1; ctx.strokeStyle = color; ctx.lineWidth = Math.max(2, c * 0.12);
    ctx.beginPath(); ctx.arc(x + c / 2, y + c / 2, c * 0.3, 0, Math.PI * 2); ctx.stroke();
    ctx.globalAlpha = 1;
  }
  function draw() {
    var st = LS ? LS : G;
    if (!st || !st.board) return;
    var cs = getComputedStyle(document.body);
    var colX = cs.getPropertyValue('--x').trim(), colO = cs.getPropertyValue('--o').trim();
    var light = document.body.classList.contains('light');
    ctx.setTransform(geo.dpr, 0, 0, geo.dpr, 0, 0);
    ctx.clearRect(0, 0, geo.size, geo.size);
    var c = geo.cell, off = geo.off, B = N * c;
    ctx.fillStyle = light ? '#ffffff' : '#1d232d';
    ctx.fillRect(off, off, B, B);
    // zvýraznění středu a hvězd
    ctx.fillStyle = light ? '#eef2f7' : '#232b37';
    [[7, 7], [3, 3], [11, 3], [3, 11], [11, 11]].forEach(function (q) { ctx.fillRect(off + q[0] * c, off + q[1] * c, c, c); });
    // poslední tah
    var moves = st.moves || [];
    var last = moves.length ? moves[moves.length - 1].p : -1;
    if (S.lastMove && last >= 0) { var lp = cellXY(last); ctx.fillStyle = light ? '#fff3b0' : '#3d3a22'; ctx.fillRect(lp[0], lp[1], c, c); }
    // výherní řada
    if (st.winLine) st.winLine.forEach(function (p) { var q = cellXY(p); ctx.fillStyle = light ? '#c8f5d6' : '#1f4d33'; ctx.fillRect(q[0], q[1], c, c); });
    // hrozby
    if (G.threats && !LS) {
      [1, 2].forEach(function (pl) {
        G.threats[pl].forEach(function (t) {
          var q = cellXY(t[0]); ctx.fillStyle = pl === 1 ? 'rgba(255,93,93,' : 'rgba(79,179,255,';
          ctx.fillStyle += (t[1] >= 7 ? '.45)' : t[1] >= 5 ? '.3)' : '.15)');
          ctx.fillRect(q[0] + c * 0.1, q[1] + c * 0.1, c * 0.8, c * 0.8);
        });
      });
    }
    // mřížka
    ctx.strokeStyle = light ? '#c9d1dc' : '#3a4352'; ctx.lineWidth = 1;
    ctx.beginPath();
    for (var i = 0; i <= N; i++) {
      var v = Math.round(off + i * c) + 0.5;
      ctx.moveTo(off, v); ctx.lineTo(off + B, v); ctx.moveTo(v, off); ctx.lineTo(v, off + B);
    }
    ctx.stroke();
    // souřadnice
    if (S.coords) {
      ctx.fillStyle = light ? '#637083' : '#8d97a7';
      ctx.font = Math.max(8, c * 0.42) + 'px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
      for (i = 0; i < N; i++) {
        ctx.fillText(LETTERS[i], off + i * c + c / 2, off / 2);
        ctx.fillText(String(N - i), off / 2, off + i * c + c / 2);
      }
    }
    // kameny
    var numMap = {};
    if (S.numbers) moves.forEach(function (m, idx) { numMap[m.p] = idx + 1; });
    for (var p = 0; p < NN; p++) {
      var s = st.board[p]; if (!s) continue;
      var xy = cellXY(p);
      if (s === 1) drawX(xy[0], xy[1], c, colX); else drawO(xy[0], xy[1], c, colO);
      if (numMap[p]) {
        ctx.fillStyle = light ? '#18202c' : '#fff'; ctx.font = 'bold ' + Math.max(7, c * 0.32) + 'px sans-serif';
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(numMap[p], xy[0] + c / 2, xy[1] + c / 2);
      }
    }
    // značky (lekce, nápovědy)
    var marks = st.marks || {};
    Object.keys(marks).forEach(function (k) {
      var p = +k, m = marks[k], q = cellXY(p);
      var col = m.color || '#ffb020';
      if (m.box) { ctx.strokeStyle = col; ctx.lineWidth = 2; ctx.strokeRect(q[0] + 2, q[1] + 2, c - 4, c - 4); }
      if (m.t) {
        ctx.fillStyle = col; ctx.font = 'bold ' + Math.max(9, c * 0.55) + 'px sans-serif';
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText(m.t, q[0] + c / 2, q[1] + c / 2 + 1);
      }
    });
    // hodnocení tahů
    if (!LS && S.analysis && G.evals) {
      Object.keys(G.evals).forEach(function (k) {
        var e = G.evals[k]; if (!e || e.pending || !LABEL_COL[e.label]) return;
        var q = cellXY(e.move), w = c * 0.52, hgt = c * 0.4;
        ctx.fillStyle = LABEL_COL[e.label];
        ctx.beginPath(); ctx.arc(q[0] + c - w * 0.42, q[1] + hgt * 0.5, hgt * 0.55, 0, Math.PI * 2); ctx.fill();
        ctx.fillStyle = '#10141b'; ctx.font = 'bold ' + Math.max(7, c * 0.3) + 'px sans-serif';
        ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(e.label === '★' ? '★' : e.label, q[0] + c - w * 0.42, q[1] + hgt * 0.52);
      });
      if (G.sel >= 0 && G.evals[G.sel] && !G.evals[G.sel].pending) {
        var se = cellXY(G.evals[G.sel].move); ctx.strokeStyle = '#4f8cff'; ctx.lineWidth = 2; ctx.strokeRect(se[0] + 1, se[1] + 1, c - 2, c - 2);
        if (G.showAlt && G.evals[G.sel].best >= 0) {
          var ab = cellXY(G.evals[G.sel].best);
          ctx.strokeStyle = '#26c6da'; ctx.lineWidth = 3; ctx.setLineDash([4, 3]); ctx.strokeRect(ab[0] + 2, ab[1] + 2, c - 4, c - 4); ctx.setLineDash([]);
          var ac = G.evals[G.sel].c;
          if (!G.board[G.evals[G.sel].best]) { if (ac === 1) drawX(ab[0], ab[1], c, colX, 0.4); else drawO(ab[0], ab[1], c, colO, 0.4); }
        }
      }
    }
    // nápověda
    var hint = st.hint;
    if (hint >= 0) { var hq = cellXY(hint); ctx.strokeStyle = '#3ccf7a'; ctx.lineWidth = 3; ctx.strokeRect(hq[0] + 2, hq[1] + 2, c - 4, c - 4); }
    // čekající tah (potvrzení)
    if (st.pending >= 0) {
      var pq = cellXY(st.pending);
      var pc = LS ? LS.toMove : (G.phase === 'play' ? toMove() : openingColor());
      ctx.fillStyle = 'rgba(79,140,255,.18)'; ctx.fillRect(pq[0], pq[1], c, c);
      if (pc === 1) drawX(pq[0], pq[1], c, colX, 0.45); else drawO(pq[0], pq[1], c, colO, 0.45);
    }
  }
  function pointToCell(ev) {
    var r = canvas.getBoundingClientRect();
    var x = ev.clientX - r.left - geo.off, y = ev.clientY - r.top - geo.off;
    var cx = Math.floor(x / geo.cell), cy = Math.floor(y / geo.cell);
    if (cx < 0 || cy < 0 || cx >= N || cy >= N) return -1;
    return cy * N + cx;
  }
  canvas.addEventListener('click', function (ev) { var p = pointToCell(ev); if (p >= 0) humanTap(p); });

  // ---------------- UČENÍ ----------------
  var progress = loadJSON('pq_progress', {});
  function allLessons() { return window.buildLessons ? window.buildLessons(window.PUZZLES || {}) : []; }
  var LESSON_LIST = null;
  function renderLearnList() {
    if (!LESSON_LIST) LESSON_LIST = allLessons();
    var el = $('#learn-list'); el.innerHTML = '';
    var intro = document.createElement('p'); intro.className = 'note';
    intro.innerHTML = 'Kurz je řazený od základů po turnajovou strategii. Každá lekce má výklad a interaktivní úlohy, které kontroluje engine – bot se brání nejlepší obranou. Úlohy se hrají s pravidlem <b>přesně 5</b>.';
    el.appendChild(intro);
    var ch = null, box = null;
    LESSON_LIST.forEach(function (L, idx) {
      if (L.chapter !== ch) {
        ch = L.chapter; box = document.createElement('div'); box.className = 'chapter';
        box.innerHTML = '<h3>' + ch + '</h3>'; el.appendChild(box);
      }
      var b = document.createElement('button');
      b.className = 'lesson-item' + (progress[L.id] ? ' done' : '');
      b.innerHTML = '<span class="num">' + (progress[L.id] ? '✓' : (idx + 1)) + '</span><span><div class="t">' + L.title + '</div><div class="d">' + (L.desc || '') + '</div></span>';
      b.onclick = function () { openLesson(idx); };
      box.appendChild(b);
    });
  }
  function openLesson(idx, stepIdx) {
    G.token++;
    var L = LESSON_LIST[idx];
    LS = { idx: idx, lesson: L, step: stepIdx || 0, board: new Int8Array(NN), moves: [], marks: {}, pending: -1, hint: -1, winLine: null };
    $('#game-title').textContent = L.title;
    $('#game-toolbar').classList.add('hidden');
    $('#lesson-toolbar').classList.remove('hidden');
    $('#lesson-text').classList.remove('hidden');
    $('#btn-confirm').classList.add('hidden');
    $('#analysis').classList.add('hidden');
    if (stack[stack.length - 1] !== 'game') go('game');
    loadStep();
    setTimeout(resizeBoard, 0);
  }
  function stonesToBoard(st) {
    var b = new Int8Array(NN), moves = [];
    function put(list, c) {
      (list || []).forEach(function (s) { var p = typeof s === 'number' ? s : parseC(s); b[p] = c; moves.push({ p: p, c: c }); });
    }
    put(st.x, 1); put(st.o, 2);
    return { b: b, moves: moves };
  }
  function loadStep() {
    var L = LS.lesson, s = L.steps[LS.step];
    var bb = stonesToBoard(s);
    LS.board = bb.b; LS.moves = [];
    LS.initial = bb.b.slice();
    LS.marks = {}; LS.pending = -1; LS.hint = -1; LS.winLine = null; LS.busy = false;
    LS.solved = false; LS.toMove = s.puzzle ? (s.puzzle.toMove || 1) : 1;
    LS.exact = s.rule !== 'free';
    LS.line = s.line2 ? s.line2.map(parseC) : null; LS.lineIdx = 0; LS.lineSide = s.side || 1;
    if (LS.line) LS.toMove = LS.lineSide;
    LS.history = [];
    if (s.marks) Object.keys(s.marks).forEach(function (k) {
      var v = s.marks[k], p = parseC(k);
      LS.marks[p] = typeof v === 'string' ? { t: v, color: '#ffb020' } : v;
    });
    if (s.line) s.line.forEach(function (k) { LS.marks[parseC(k)] = { box: true, color: '#3ccf7a' }; });
    var head = '<span class="pos">Krok ' + (LS.step + 1) + ' / ' + L.steps.length + '</span>';
    var html = head + (s.title ? '<h3>' + s.title + '</h3>' : '') + (s.text || '');
    if (s.puzzle) {
      var k = s.puzzle;
      var who = sym(LS.toMove);
      var task = k.kind === 'defend'
        ? 'Úloha: hraješ za ' + who + '. Soupeř hrozí vítěznou sérií – najdi obranu.'
        : (k.mode === 'vcf' ? 'Úloha: hraješ za ' + who + '. Vyhraj jen pomocí čtyřek (VCF).' : 'Úloha: hraješ za ' + who + '. Vyhraj vynucenou sérií (čtyřky a otevřené trojky).');
      html += '<p><b>' + task + '</b></p><div id="lesson-result"></div>';
    }
    if (LS.line) html += '<p><b>Hraješ za ' + sym(LS.lineSide) + '.</b> Zahraj tahy schématu – soupeřovy odpovědi se zahrají samy. (Pravidlo: ' + (LS.exact ? 'přesně 5' : '5 a více') + ')</p><div id="lesson-result"></div>';
    if (s.play) html += '<p><button class="primary" id="btn-play-schema">▶ Hrát tuto pozici proti botovi (' + (s.play.side === 1 ? '✕' : '◯') + ')</button></p>';
    $('#lesson-text').innerHTML = html;
    $('#lesson-text').scrollTop = 0;
    var bp = $('#btn-play-schema');
    if (bp) bp.onclick = function () {
      var st = s.play.start || { x: s.x, o: s.o };
      G.token++; LS = null;
      startGame({ mode: 'bot', start: st, human: s.play.side, rule: s.rule === 'free' ? 'free' : 'exact', level: s.play.level || 6 });
      setTimeout(resizeBoard, 0);
    };
    $('#btn-lprev').disabled = LS.step === 0;
    $('#btn-lhint').classList.toggle('hidden', !s.puzzle && !LS.line);
    $('#btn-lretry').classList.toggle('hidden', !s.puzzle && !LS.line);
    $('#btn-lnext').textContent = LS.step === L.steps.length - 1 ? 'Hotovo ✓' : 'Dál ›';
    $('#status').innerHTML = s.puzzle ? ('Na tahu: ' + sym(LS.toMove) + (s.puzzle.kind === 'defend' ? ' · obrana' : ' · útok')) : (LS.line ? 'Schéma' : 'Výklad');
    draw();
    if (LS.line) lineAdvance();
  }
  // ---- nácvik varianty schématu ----
  function lineColorAt(i) { var c = countStones(LS.board); return c[0] === c[1] ? 1 : 2; }
  function lineAdvance() {
    var tok = G.token;
    if (!LS || !LS.line) return;
    if (LS.lineIdx >= LS.line.length) {
      LS.solved = true;
      var last = LS.moves.length ? LS.moves[LS.moves.length - 1].p : -1;
      if (last >= 0) LS.winLine = localE.winLine(LS.board, last, LS.exact);
      $('#status').innerHTML = '✔ Varianta zvládnutá';
      lessonResult('✔ Varianta zvládnutá! ' + (LS.winLine ? 'Pětka.' : '') + ' Zkus ji zopakovat zpaměti (⟳), pak pokračuj.', 'res-ok');
      draw(); return;
    }
    var c = lineColorAt();
    if (c === LS.lineSide) { $('#status').innerHTML = 'Na tahu: ' + sym(c) + ' (ty) · tah ' + (LS.lineIdx + 1); return; }
    LS.busy = true;
    $('#status').innerHTML = 'Soupeř hraje…';
    setTimeout(function () {
      if (tok !== G.token || !LS) return;
      var p = LS.line[LS.lineIdx++];
      LS.board[p] = c; LS.moves.push({ p: p, c: c }); LS.busy = false; LS.marks = {}; LS.hint = -1;
      draw(); lineAdvance();
    }, 450);
  }
  function lineTap(p) {
    var expected = LS.line[LS.lineIdx];
    if (p === expected) {
      LS.board[p] = LS.lineSide; LS.moves.push({ p: p, c: LS.lineSide }); LS.lineIdx++;
      LS.marks = {}; LS.hint = -1; LS.errors = 0;
      lessonResult('✔ ' + cname(p) + ' – správně.', 'res-ok');
      draw(); lineAdvance();
    } else {
      LS.errors = (LS.errors || 0) + 1;
      LS.marks = {}; LS.marks[p] = { t: '?', color: '#ff6b6b' };
      if (LS.errors >= 2) { LS.hint = expected; lessonResult('✘ Ve schématu se hraje <b>' + cname(expected) + '</b> (zeleně). Zapamatuj si proč – podívej se, jakou hrozbu vytváří.', 'res-bad'); }
      else lessonResult('✘ ' + cname(p) + ' není tah schématu. Zkus to znovu.', 'res-bad');
      draw();
    }
  }
  function lessonResult(html, cls) {
    var el = $('#lesson-result'); if (!el) return;
    el.innerHTML = '<p class="' + (cls || '') + '">' + html + '</p>';
    var lt = $('#lesson-text'); lt.scrollTop = lt.scrollHeight;
  }
  function lessonTap(p) {
    var s = LS.lesson.steps[LS.step];
    if (LS.line) {
      if (LS.busy || LS.solved || LS.board[p] || lineColorAt() !== LS.lineSide) return;
      if (S.confirmMove && LS.pending !== p) { LS.pending = p; draw(); $('#btn-confirm').classList.remove('hidden'); return; }
      $('#btn-confirm').classList.add('hidden'); LS.pending = -1;
      lineTap(p); return;
    }
    if (!s.puzzle || LS.busy || LS.solved) return;
    if (LS.board[p]) return;
    if (S.confirmMove && LS.pending !== p) { LS.pending = p; draw(); $('#btn-confirm').classList.remove('hidden'); return; }
    $('#btn-confirm').classList.add('hidden');
    LS.pending = -1;
    lessonCommit(p);
  }
  function lessonCommit(p) {
    var s = LS.lesson.steps[LS.step], k = s.puzzle, me = LS.toMove, tok = G.token;
    LS.busy = true; LS.hint = -1;
    LS.marks = {};
    $('#status').innerHTML = '<span class="spinner"></span> Engine kontroluje tah ' + cname(p) + '…';
    if (k.kind === 'defend') {
      Engine.call('checkDefense', { board: LS.board, move: p, def: me, exact: LS.exact, useVct: k.mode !== 'vcf' }).then(function (r) {
        if (tok !== G.token || !LS) return;
        LS.busy = false;
        LS.board[p] = me; LS.moves.push({ p: p, c: me });
        if (r.ok) {
          LS.solved = true;
          $('#status').innerHTML = '✔ Vyřešeno';
          lessonResult('✔ Správně! Po ' + cname(p) + ' už soupeř nemá vynucenou výhru.' + (k.explain ? '<br>' + k.explain : ''), 'res-ok');
          markStepDone();
        } else {
          var f = r.seq && r.seq[0];
          if (f !== undefined) LS.marks[f] = { t: '!', color: '#ff6b6b' };
          $('#status').innerHTML = '✘ Nestačí';
          lessonResult('✘ ' + cname(p) + ' nestačí – soupeř pořád vyhraje' + (f !== undefined ? ', např. tahem <b>' + cname(f) + '</b> (označeno !)' : '') + '. Zkus to znovu (⟳).', 'res-bad');
        }
        draw();
      });
      return;
    }
    Engine.call('checkAttack', { board: LS.board, move: p, att: me, exact: LS.exact, mode: k.mode || 'vct' }).then(function (r) {
      if (tok !== G.token || !LS) return;
      if (r.ok) {
        LS.board[p] = me; LS.moves.push({ p: p, c: me });
        if (r.done) {
          LS.winLine = localE.winLine(LS.board, p, LS.exact);
          LS.busy = false; LS.solved = true;
          $('#status').innerHTML = '✔ Pětka!';
          lessonResult('✔ Výborně, pětka! Úloha vyřešena.' + (k.explain ? '<br>' + k.explain : ''), 'res-ok');
          markStepDone(); draw(); return;
        }
        draw();
        $('#status').innerHTML = '<span class="spinner"></span> Soupeř se brání…';
        setTimeout(function () {
          if (tok !== G.token || !LS) return;
          LS.board[r.reply] = 3 - me; LS.moves.push({ p: r.reply, c: 3 - me });
          LS.busy = false;
          $('#status').innerHTML = 'Soupeř: ' + cname(r.reply) + ' · pokračuj';
          var note = '';
          if (k.best && LS.moves.length === 2 && k.best.indexOf(cname(p)) < 0) note = ' Tento tah taky vyhrává, ale nejpřímější cesta je <b>' + k.best.join(' / ') + '</b>.';
          lessonResult('Dobře (' + cname(p) + '). Soupeř se bránil na ' + cname(r.reply) + '. Pokračuj!' + note, '');
          draw();
        }, 350);
      } else {
        LS.busy = false;
        var msg = {
          notFour: 'V této úloze musí být každý tah čtyřka (VCF).',
          noThreat: 'Tento tah nic nevynucuje – soupeř dostane volný tah a ubrání se.',
          refuted: 'Tímto tahem výhru nevynutíš – soupeř se ubrání',
          ignoredFour: 'Pozor! Soupeř má čtyřku – nejdřív ji musíš zablokovat (nebo udělat pětku).',
          defWins: 'Soupeř by blokem udělal pětku!',
          occupied: 'Pole je obsazené.'
        }[r.reason] || 'Tah nevede k výhře.';
        if (r.refute !== undefined) { LS.marks[r.refute] = { t: '!', color: '#ff6b6b' }; msg += (r.reason === 'refuted' ? ' tahem <b>' + cname(r.refute) + '</b> (!).' : ''); }
        LS.marks[p] = { t: '?', color: '#ff6b6b' };
        $('#status').innerHTML = '✘ ' + cname(p) + ' nevede k výhře';
        lessonResult('✘ ' + msg + ' Zkus jiný tah.', 'res-bad');
        draw();
      }
    });
  }
  function markStepDone() {
    var L = LS.lesson;
    LS.doneSteps = LS.doneSteps || {};
    LS.doneSteps[LS.step] = true;
  }
  $('#btn-lprev').onclick = function () { if (LS && LS.step > 0) { G.token++; LS.step--; loadStep(); } };
  $('#btn-lnext').onclick = function () {
    if (!LS) return;
    G.token++;
    if (LS.step < LS.lesson.steps.length - 1) { LS.step++; loadStep(); }
    else {
      progress[LS.lesson.id] = true; saveJSON('pq_progress', progress);
      var nextIdx = LS.idx + 1;
      modal('Lekce dokončena ✓', LS.lesson.title, [
        nextIdx < LESSON_LIST.length ? { label: 'Další lekce: ' + LESSON_LIST[nextIdx].title, primary: true, fn: function () { openLesson(nextIdx); } } : null,
        { label: 'Seznam lekcí', fn: function () { back(); } },
        { label: 'Zůstat zde' }
      ].filter(Boolean));
    }
  };
  $('#btn-lretry').onclick = function () { if (LS) { G.token++; loadStep(); } };
  $('#btn-lhint').onclick = function () {
    if (!LS || LS.busy) return;
    var s = LS.lesson.steps[LS.step], k = s.puzzle;
    if (LS.line) { if (LS.lineIdx < LS.line.length) { LS.hint = LS.line[LS.lineIdx]; draw(); lessonResult('💡 Tah schématu: <b>' + cname(LS.hint) + '</b>', ''); } return; }
    if (!k) return;
    var tok = G.token;
    LS.busy = true; $('#status').innerHTML = '<span class="spinner"></span> Hledám…';
    if (k.kind === 'defend') {
      Engine.call('solve', { board: LS.board, att: 3 - LS.toMove, exact: LS.exact, mode: k.mode || 'vct' }).then(function (seq) {
        if (tok !== G.token || !LS) return;
        LS.busy = false;
        if (seq && seq.length) {
          LS.marks[seq[0]] = { t: '!', color: '#ff6b6b' };
          $('#status').innerHTML = 'Nápověda';
          lessonResult('💡 Soupeř hrozí zahrát <b>' + cname(seq[0]) + '</b> (!) a spustit sérii. Obrana bývá na tomto poli, na polích jeho série, nebo protiútok čtyřkou.', '');
        } else lessonResult('💡 Soupeř už nemá vynucenou výhru.', '');
        draw();
      });
    } else {
      Engine.call('solve', { board: LS.board, att: LS.toMove, exact: LS.exact, mode: k.mode || 'vct' }).then(function (seq) {
        if (tok !== G.token || !LS) return;
        LS.busy = false;
        if (seq && seq.length) { LS.hint = seq[0]; $('#status').innerHTML = 'Nápověda: ' + cname(seq[0]); lessonResult('💡 Zkus <b>' + cname(seq[0]) + '</b> (zeleně).', ''); }
        else lessonResult('💡 Engine teď nenašel vynucenou výhru – zkus úlohu restartovat (⟳).', '');
        draw();
      });
    }
  };
  function lessonMenu() {
    modal('Lekce', LS.lesson.title, [
      { label: 'Seznam lekcí', fn: function () { back(); } },
      { label: 'Začít lekci od začátku', fn: function () { LS.step = 0; G.token++; loadStep(); } },
      { label: 'Zavřít' }
    ]);
  }

  // ---------------- NASTAVENÍ ----------------
  var SETTINGS_DEF = [
    ['analysis', 'Hodnocení tahů', 'Po každém tvém tahu engine řekne, jestli byl dobrý (!!, !, ★, ✓, ?!, ?, ??), vysvětlí proč a ukáže lepší tah.'],
    ['confirmMove', 'Potvrzování tahu', 'První ťuknutí ukáže tah, druhé (nebo „Potvrdit“) ho zahraje. Chrání před překlepem.'],
    ['coords', 'Souřadnice', 'Písmena A–O a čísla 1–15 kolem desky.'],
    ['lastMove', 'Zvýraznit poslední tah', ''],
    ['numbers', 'Čísla tahů', 'Pořadí tahů přímo na kamenech.'],
    ['hints', 'Tlačítko nápovědy', 'V běžné hře.'],
    ['undo', 'Vracení tahů', 'V běžné hře.'],
    ['threats', 'Zobrazovat hrozby', 'Barevně podbarví pole, kde vzniká čtyřka / otevřená čtyřka / vidlička (výukové).'],
    ['botDelay', 'Krátká pauza před tahem bota', ''],
    ['light', 'Světlý vzhled', ''],
    ['stats', 'Statistiky', 'Ve výchozím stavu vypnuto. Po zapnutí se ukládají výsledky proti botům.']
  ];
  function renderSettings() {
    var el = $('#settings-list'); el.innerHTML = '';
    SETTINGS_DEF.forEach(function (d) {
      var row = document.createElement('div'); row.className = 'setting';
      row.innerHTML = '<div class="lbl">' + d[1] + (d[2] ? '<small>' + d[2] + '</small>' : '') + '</div>';
      var sw = document.createElement('button'); sw.className = 'switch' + (S[d[0]] ? ' on' : '');
      sw.onclick = function () { S[d[0]] = !S[d[0]]; sw.classList.toggle('on', S[d[0]]); saveSettings(); applySettings(); };
      row.appendChild(sw); el.appendChild(row);
    });
    var r = document.createElement('div'); r.className = 'setting';
    r.innerHTML = '<div class="lbl">Smazat postup v lekcích</div>';
    var b = document.createElement('button'); b.textContent = 'Smazat';
    b.onclick = function () { progress = {}; saveJSON('pq_progress', progress); toast('Postup smazán'); };
    r.appendChild(b); el.appendChild(r);
    var ab = document.createElement('p'); ab.className = 'note';
    ab.innerHTML = 'Pravidlo „přesně 5“: šestka a delší řada nevyhrává (standard Gomoku, používaný se Swap2). „5 a více“: vyhrává i delší řada (freestyle).';
    el.appendChild(ab);
  }
  function applySettings() {
    document.body.classList.toggle('light', !!S.light);
    $('#btn-stats').classList.toggle('hidden', !S.stats);
    $('#btn-hint').classList.toggle('hidden', !S.hints);
    $('#btn-undo').classList.toggle('hidden', !S.undo);
    renderAnalysis();
    resizeBoard();
  }
  function renderStats() {
    var st = loadJSON('pq_stats', {});
    var h = '<table class="stats"><tr><th>Bot</th><th>Výhry</th><th>Prohry</th><th>Remízy</th></tr>';
    for (var l = 1; l <= 6; l++) { var r = st['L' + l] || { w: 0, l: 0, d: 0 }; h += '<tr><td>' + LEVEL_NAMES[l] + '</td><td>' + r.w + '</td><td>' + r.l + '</td><td>' + r.d + '</td></tr>'; }
    h += '</table><p><button id="btn-clear-stats">Vynulovat statistiky</button></p>';
    $('#stats-body').innerHTML = h;
    $('#btn-clear-stats').onclick = function () { saveJSON('pq_stats', {}); renderStats(); };
  }

  // ---------------- start ----------------
  loadSettings();
  applySettings();
  show('menu');
})();
