# Piškvorky Trenér (Android)

Aplikace na trénink piškvorek (gomoku) 15×15: boti 6 obtížností, klasické zahájení / Swap1 / Swap2,
hra dvou hráčů na jednom zařízení a výukový kurz s úlohami, které kontroluje engine.

## Jak z toho na GitHubu udělat APK (bez instalace čehokoli do PC)

1. Na **github.com** se přihlas → vpravo nahoře **+** → **New repository**.
   Název např. `piskvorky-trener`, nech **Public** nebo **Private**, klikni **Create repository**.
2. Na stránce nového repa klikni na odkaz **uploading an existing file**.
3. Rozbal ZIP a **přetáhni do okna prohlížeče celý obsah složky `piskvorky`**
   (složky `app`, `.github` a soubory `build.gradle`, `settings.gradle`, `gradle.properties`, `README.md`).
   - Pozor: složka `.github` je „skrytá“. Na Windows ji uvidíš po zapnutí *Zobrazit → Skryté položky*,
     na Macu klávesami `Cmd + Shift + .`. Bez ní se APK nesestaví.
   - Pokud přetažení `.github` nejde: nahraj zbytek a pak *Add file → Create new file*, do názvu napiš
     `.github/workflows/build.yml` a vlož obsah souboru `build.yml` z ZIPu.
4. Dole klikni **Commit changes**.
5. Nahoře otevři záložku **Actions**. Build „Build APK“ se spustí sám (cca 3–5 minut).
   Pokud ne, klikni vlevo na **Build APK** → **Run workflow**.
6. Až je u buildu zelená fajfka ✅, klikni na něj a dole v sekci **Artifacts** stáhni
   `piskvorky-trener-apk` (ZIP, uvnitř je `app-debug.apk`).
7. APK pošli do telefonu (nebo stáhni přímo v mobilu přes GitHub v prohlížeči), otevři ho a povol
   instalaci z neznámých zdrojů. Hotovo.

Každá další změna souborů v repu spustí nový build automaticky.

## Struktura

```
.github/workflows/build.yml      – GitHub Actions: sestaví APK
settings.gradle, build.gradle    – nastavení Gradle projektu
gradle.properties
app/build.gradle                 – nastavení aplikace (název balíčku, verze Androidu)
app/src/main/AndroidManifest.xml
app/src/main/java/.../MainActivity.java  – Android obal (WebView)
app/src/main/res/drawable/ic_launcher.xml – ikona
app/src/main/assets/             – samotná aplikace (běží offline)
   index.html, style.css, app.js – rozhraní
   engine.js                     – AI: vzory, alfa-beta, VCF/VCT solver
   lessons.js                    – výukový kurz
   puzzles.js                    – úlohy vygenerované z partií enginu
```

Aplikaci jde vyzkoušet i na PC: otevři `app/src/main/assets/index.html` v Chrome.
