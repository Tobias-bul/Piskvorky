// Piškvorky – herní engine (15x15, přesně 5 / 5 a více)
// Funguje ve Web Workeru, v hlavním vlákně i v Node (testy).
function EngineModule() {
  'use strict';
  var N = 15, NN = 225;
  var DX = [1, 0, 1, 1], DY = [0, 1, 1, -1];
  var OFFS = [-5, -4, -3, -2, -1, 1, 2, 3, 4, 5];
  var P3 = [1, 3, 9, 27, 81, 243, 729, 2187, 6561, 19683];
  // typy v jedné linii (pro kámen položený na dané pole)
  var NONE = 0, ONE = 1, TWO = 2, OPEN2 = 3, THREE = 4, OPEN3 = 5, FOUR = 6, OPEN4 = 7, FIVE = 8;
  var WIN = 1000000;

  // ---------- tabulka vzorů ----------
  var tables = {};
  function buildTable(exact) {
    var tab = new Int8Array(59049).fill(-1);
    var c = new Int8Array(11);
    function typeOf(key) {
      var t = tab[key];
      if (t >= 0) return t;
      var k = key, j;
      for (j = 0; j < 10; j++) { c[OFFS[j] + 5] = k % 3; k = (k - k % 3) / 3; }
      c[5] = 1;
      var l = 5, r = 5;
      while (l > 0 && c[l - 1] === 1) l--;
      while (r < 10 && c[r + 1] === 1) r++;
      var len = r - l + 1;
      if (exact ? len === 5 : len >= 5) { tab[key] = FIVE; return FIVE; }
      var empt = [];
      for (j = 0; j < 10; j++) if (Math.abs(OFFS[j]) <= 4 && c[OFFS[j] + 5] === 0) empt.push(j);
      var fives = 0, has4o = false, has4 = false, has3o = false, has3 = false, has2 = false;
      for (var i = 0; i < empt.length; i++) {
        var ct = typeOf(key + P3[empt[i]]);
        if (ct === FIVE) fives++;
        else if (ct === OPEN4) has4o = true;
        else if (ct === FOUR) has4 = true;
        else if (ct === OPEN3) has3o = true;
        else if (ct === THREE) has3 = true;
        else if (ct === TWO || ct === OPEN2) has2 = true;
      }
      if (fives >= 2) t = OPEN4;
      else if (fives === 1) t = FOUR;
      else if (has4o) t = OPEN3;
      else if (has4) t = THREE;
      else if (has3o) t = OPEN2;
      else if (has3) t = TWO;
      else if (has2) t = ONE;
      else t = NONE;
      tab[key] = t;
      return t;
    }
    for (var key = 0; key < 59049; key++) typeOf(key);
    return tab;
  }

  // sousedé: NB[(p*4+d)*10 + j]
  var NB = new Int16Array(NN * 4 * 10);
  (function () {
    for (var p = 0; p < NN; p++) {
      var x = p % N, y = (p / N) | 0;
      for (var d = 0; d < 4; d++) for (var j = 0; j < 10; j++) {
        var xx = x + DX[d] * OFFS[j], yy = y + DY[d] * OFFS[j];
        NB[(p * 4 + d) * 10 + j] = (xx < 0 || yy < 0 || xx >= N || yy >= N) ? -1 : yy * N + xx;
      }
    }
  })();
  // okolí pro "near" (vzdálenost 2)
  var AROUND = [];
  (function () {
    for (var p = 0; p < NN; p++) {
      var x = p % N, y = (p / N) | 0, a = [];
      for (var dy = -2; dy <= 2; dy++) for (var dx = -2; dx <= 2; dx++) {
        if (!dx && !dy) continue;
        var xx = x + dx, yy = y + dy;
        if (xx >= 0 && yy >= 0 && xx < N && yy < N) a.push(yy * N + xx);
      }
      AROUND.push(a);
    }
  })();

  // zobrist
  var Z1 = [null, new Int32Array(NN), new Int32Array(NN)], Z2 = [null, new Int32Array(NN), new Int32Array(NN)];
  (function () {
    var s = 123456789;
    function rnd() { s ^= s << 13; s ^= s >>> 17; s ^= s << 5; return s | 0; }
    for (var pl = 1; pl <= 2; pl++) for (var p = 0; p < NN; p++) { Z1[pl][p] = rnd(); Z2[pl][p] = rnd(); }
  })();

  // ---------- stav ----------
  var board = new Int8Array(NN);
  var pat = [null, new Int8Array(NN * 4), new Int8Array(NN * 4)];
  var near = new Int8Array(NN);
  var tab = null, exactRule = true;
  var h1 = 0, h2 = 0, count = 0;

  function computePat(q) {
    for (var d = 0; d < 4; d++) {
      var base = (q * 4 + d) * 10, k1 = 0, k2 = 0;
      for (var j = 0; j < 10; j++) {
        var r = NB[base + j], v1, v2;
        if (r < 0) { v1 = 2; v2 = 2; }
        else { var b = board[r]; if (b === 0) { v1 = 0; v2 = 0; } else if (b === 1) { v1 = 1; v2 = 2; } else { v1 = 2; v2 = 1; } }
        k1 += v1 * P3[j]; k2 += v2 * P3[j];
      }
      pat[1][q * 4 + d] = tab[k1];
      pat[2][q * 4 + d] = tab[k2];
    }
  }
  function computePatDir(q, d) {
    var base = (q * 4 + d) * 10, k1 = 0, k2 = 0;
    for (var j = 0; j < 10; j++) {
      var r = NB[base + j], v1, v2;
      if (r < 0) { v1 = 2; v2 = 2; }
      else { var b = board[r]; if (b === 0) { v1 = 0; v2 = 0; } else if (b === 1) { v1 = 1; v2 = 2; } else { v1 = 2; v2 = 1; } }
      k1 += v1 * P3[j]; k2 += v2 * P3[j];
    }
    pat[1][q * 4 + d] = tab[k1];
    pat[2][q * 4 + d] = tab[k2];
  }
  function updateLines(p) {
    for (var d = 0; d < 4; d++) {
      var base = (p * 4 + d) * 10;
      for (var j = 0; j < 10; j++) {
        var q = NB[base + j];
        if (q >= 0 && board[q] === 0) computePatDir(q, d);
      }
    }
  }
  function place(p, pl) {
    board[p] = pl; count++;
    h1 ^= Z1[pl][p]; h2 ^= Z2[pl][p];
    var a = AROUND[p]; for (var i = 0; i < a.length; i++) near[a[i]]++;
    updateLines(p);
  }
  function remove(p) {
    var pl = board[p];
    board[p] = 0; count--;
    h1 ^= Z1[pl][p]; h2 ^= Z2[pl][p];
    var a = AROUND[p]; for (var i = 0; i < a.length; i++) near[a[i]]--;
    updateLines(p);
    computePat(p);
  }
  function setup(arr, exact) {
    exactRule = !!exact;
    var key = exactRule ? 'e' : 'f';
    if (!tables[key]) tables[key] = buildTable(exactRule);
    tab = tables[key];
    board.fill(0); near.fill(0); h1 = 0; h2 = 0; count = 0;
    for (var p = 0; p < NN; p++) computePat(p);
    for (p = 0; p < NN; p++) if (arr[p]) place(p, arr[p]);
  }

  // ---------- vyhodnocení pole ----------
  // úroveň hrozby pro hráče pl na prázdném poli p
  function level(p, pl) {
    var o = p * 4, P = pat[pl], n4 = 0, n3 = 0, five = false, o4 = false;
    for (var d = 0; d < 4; d++) {
      var t = P[o + d];
      if (t === FIVE) five = true;
      else if (t === OPEN4) o4 = true;
      else if (t === FOUR) n4++;
      else if (t === OPEN3) n3++;
    }
    if (five) return 9;
    if (o4 || n4 >= 2) return 8;
    if (n4 && n3) return 7;
    if (n3 >= 2) return 6;
    if (n4) return 5;
    if (n3) return 4;
    return 0;
  }
  var VAL = [0, 2, 6, 14, 16, 60, 70, 600, 6000];
  function cellScore(p, pl) {
    var o = p * 4, P = pat[pl], s = 0, n4 = 0, n3 = 0;
    for (var d = 0; d < 4; d++) {
      var t = P[o + d]; s += VAL[t];
      if (t === FOUR || t === OPEN4) n4++; else if (t === OPEN3) n3++;
    }
    if (n4 >= 2) s += 1500; else if (n4 && n3) s += 800; else if (n3 >= 2) s += 300;
    return s;
  }
  function isFour(p, pl) { var o = p * 4, P = pat[pl]; for (var d = 0; d < 4; d++) { var t = P[o + d]; if (t === FOUR || t === OPEN4) return true; } return false; }
  function isFive(p, pl) { var o = p * 4, P = pat[pl]; return P[o] === FIVE || P[o + 1] === FIVE || P[o + 2] === FIVE || P[o + 3] === FIVE; }
  function isThreat(p, pl) { var o = p * 4, P = pat[pl]; for (var d = 0; d < 4; d++) { var t = P[o + d]; if (t >= OPEN3 && t !== FIVE) return true; if (t === FIVE) return true; } return false; }

  function fivePointsAll(pl) {
    var r = [];
    for (var p = 0; p < NN; p++) if (board[p] === 0 && near[p] && isFive(p, pl)) r.push(p);
    return r;
  }
  function fivePointsAround(p0, pl) {
    var r = [];
    for (var d = 0; d < 4; d++) {
      var base = (p0 * 4 + d) * 10;
      for (var j = 1; j < 9; j++) {
        var q = NB[base + j];
        if (q >= 0 && board[q] === 0 && pat[pl][q * 4 + d] === FIVE && r.indexOf(q) < 0) r.push(q);
      }
    }
    return r;
  }
  function hasOpen4Point(pl) { // má hráč otevřenou trojku (pole, kde vznikne otevřená čtyřka / 4-4)
    for (var p = 0; p < NN; p++) if (board[p] === 0 && near[p] && level(p, pl) >= 8) return true;
    return false;
  }

  // ---------- VCF ----------
  var nodes = 0, nodeLimit = 0, deadline = 0, aborted = false;
  var vcfFail = new Map();
  function vcfRec(att, depth, lastDef) {
    var def = 3 - att;
    if ((++nodes & 1023) === 0 && (Date.now() > deadline)) aborted = true;
    if (aborted || nodes > nodeLimit) { aborted = true; return null; }
    var cands;
    var dfives = lastDef >= 0 ? fivePointsAround(lastDef, def) : fivePointsAll(def);
    if (dfives.length > 1) return null;
    var key = (h1 ^ (att * 0x5bd1e995)) >>> 0;
    var fv = vcfFail.get(key);
    if (fv !== undefined && fv >= depth) return null;
    if (dfives.length === 1) {
      if (!isFour(dfives[0], att)) { vcfFail.set(key, 99); return null; }
      cands = dfives;
    } else {
      cands = [];
      for (var p = 0; p < NN; p++) if (board[p] === 0 && near[p] && isFour(p, att)) {
        if (isFive(p, att)) return [p];
        cands.push(p);
      }
      if (cands.length === 0) { vcfFail.set(key, 99); return null; }
      // nejdřív tahy s otevřenou čtyřkou / vidličkou
      cands.sort(function (a, b) { return cellScore(b, att) - cellScore(a, att); });
    }
    if (dfives.length === 1 && isFive(cands[0], att)) return [cands[0]];
    if (depth <= 0) return null;
    for (var i = 0; i < cands.length; i++) {
      var c = cands[i];
      if (level(c, att) >= 8) return [c];
      place(c, att);
      var fp = fivePointsAround(c, att);
      if (fp.length >= 2) { remove(c); return [c]; }
      if (fp.length === 0) { remove(c); continue; }
      var d = fp[0];
      if (isFive(d, def)) { remove(c); continue; }
      place(d, def);
      var sub = vcfRec(att, depth - 1, d);
      remove(d); remove(c);
      if (sub) return [c, d].concat(sub);
      if (aborted) return null;
    }
    vcfFail.set(key, depth);
    return null;
  }
  function findVCF(att, maxDepth, limit, msLimit) {
    nodes = 0; nodeLimit = limit || 200000; aborted = false;
    deadline = Date.now() + (msLimit || 2000);
    vcfFail = new Map();
    // pokud útočník hned vyhrává
    var f = fivePointsAll(att); if (f.length) return [f[0]];
    return vcfRec(att, maxDepth || 30, -1);
  }

  // ---------- VCT (hrozby trojkami i čtyřkami) ----------
  var vctFail = new Map();
  // stav po tahu útočníka: vrací {kind:'five'|'four'|'three'|'none', def:[...]}
  function threatStatus(att, c) {
    var def = 3 - att;
    var fp = fivePointsAround(c, att);
    if (fp.length >= 2) return { kind: 'win' };
    if (fp.length === 1) return { kind: 'four', def: fp };
    // otevřená trojka: existuje pole s úrovní >= 8 pro útočníka
    var defs = [], any = false;
    for (var p = 0; p < NN; p++) {
      if (board[p] !== 0 || !near[p]) continue;
      if (level(p, att) >= 8) any = true;
    }
    if (!any) return { kind: 'none' };
    for (p = 0; p < NN; p++) {
      if (board[p] !== 0 || !near[p]) continue;
      if (isFour(p, att) || isFour(p, def)) defs.push(p);
    }
    return { kind: 'three', def: defs };
  }
  function vctRec(att, depth, lastDef, vcfDepth) {
    var def = 3 - att;
    if ((++nodes & 255) === 0 && Date.now() > deadline) aborted = true;
    if (aborted || nodes > nodeLimit) { aborted = true; return null; }
    var dfives = lastDef >= 0 ? fivePointsAround(lastDef, def) : fivePointsAll(def);
    if (dfives.length > 1) return null;
    // vlastní pětka
    if (dfives.length === 0) {
      for (var p = 0; p < NN; p++) if (board[p] === 0 && near[p] && isFive(p, att)) return [p];
    } else if (isFive(dfives[0], att)) return [dfives[0]];
    var key = (h1 ^ (att * 0x2545F491)) >>> 0;
    var fv = vctFail.get(key);
    if (fv !== undefined && fv >= depth) return null;
    // VCF má přednost
    if (dfives.length === 0) {
      var savedFail = vcfFail; vcfFail = new Map();
      var v = vcfRec(att, vcfDepth, lastDef);
      vcfFail = savedFail;
      if (v) return v;
      if (aborted) return null;
    }
    if (depth <= 0) return null;
    var cands = [];
    if (dfives.length === 1) cands = dfives;
    else {
      // pokud má obránce VCF, trojky nestačí (VCF útočníka už selhalo)
      var sf = vcfFail; vcfFail = new Map();
      var n0 = nodes;
      var dv = vcfRec(def, vcfDepth, -1);
      vcfFail = sf;
      if (aborted) return null;
      if (dv) { vctFail.set(key, depth); return null; }
      for (p = 0; p < NN; p++) {
        if (board[p] !== 0 || !near[p]) continue;
        var o = p * 4, P = pat[att], ok = false;
        for (var dd = 0; dd < 4; dd++) { var t = P[o + dd]; if (t === OPEN3 || t === FOUR || t === OPEN4) { ok = true; break; } }
        if (ok) cands.push(p);
      }
      cands.sort(function (a, b) { return (cellScore(b, att) + cellScore(b, def) * 0.5) - (cellScore(a, att) + cellScore(a, def) * 0.5); });
      if (cands.length > 14) cands.length = 14;
    }
    for (var i = 0; i < cands.length; i++) {
      var c = cands[i];
      place(c, att);
      var st = threatStatus(att, c);
      if (st.kind === 'win') { remove(c); return [c]; }
      if (st.kind === 'none') { remove(c); continue; }
      var allWin = true, line = null, best = null;
      var defs = st.def;
      if (st.kind === 'four' && isFive(defs[0], def)) { remove(c); continue; }
      for (var k = 0; k < defs.length; k++) {
        var d = defs[k];
        place(d, def);
        var sub = vctRec(att, depth - 1, d, vcfDepth);
        remove(d);
        if (!sub) { allWin = false; break; }
        if (!best || sub.length > best.length) { best = sub; line = d; }
      }
      remove(c);
      if (aborted) return null;
      if (allWin && defs.length) return [c, line].concat(best);
    }
    vctFail.set(key, depth);
    return null;
  }
  function findVCT(att, maxDepth, limit, msLimit, vcfDepth) {
    nodes = 0; nodeLimit = limit || 100000; aborted = false;
    deadline = Date.now() + (msLimit || 2000);
    vcfFail = new Map(); vctFail = new Map();
    var f = fivePointsAll(att); if (f.length) return [f[0]];
    var r = vctRec(att, maxDepth || 6, -1, vcfDepth || 12);
    return r;
  }

  // ---------- generování tahů ----------
  function genMoves(me, maxN) {
    var opp = 3 - me, list = [], p;
    var oppFive = [], myOpp4 = false;
    for (p = 0; p < NN; p++) {
      if (board[p] !== 0 || !near[p]) continue;
      if (isFive(p, me)) return { win: p };
      if (isFive(p, opp)) oppFive.push(p);
    }
    if (oppFive.length) return { forced: oppFive };
    var defend = false;
    for (p = 0; p < NN; p++) {
      if (board[p] !== 0 || !near[p]) continue;
      if (level(p, me) >= 8) return { win2: p };
      if (level(p, opp) >= 8) defend = true;
    }
    for (p = 0; p < NN; p++) {
      if (board[p] !== 0 || !near[p]) continue;
      if (defend && !isFour(p, opp) && !isFour(p, me)) continue;
      var a = cellScore(p, me), b = cellScore(p, opp);
      list.push({ p: p, s: a * 1.0 + b * PRM.def });
    }
    list.sort(function (x, y) { return y.s - x.s; });
    if (maxN && list.length > maxN) list.length = maxN;
    return { moves: list.map(function (m) { return m.p; }), defend: defend };
  }

  var PRM = { def: 0.85, ev: 2 };
  function evaluate(me) {
    var opp = 3 - me, sm = 0, so = 0, mm = 0, mo = 0, p;
    if (PRM.ev === 1) {
      for (p = 0; p < NN; p++) {
        if (board[p] !== 0 || !near[p]) continue;
        var a1 = cellScore(p, me), b1 = cellScore(p, opp);
        sm += a1; so += b1; if (a1 > mm) mm = a1; if (b1 > mo) mo = b1;
      }
      return (sm - so) * 0.5 + (mm - mo * 0.9);
    }
    var myFork = false, my4 = 0, opp3 = 0, oppFork = 0, myF33 = false;
    for (p = 0; p < NN; p++) {
      if (board[p] !== 0 || !near[p]) continue;
      var a = cellScore(p, me), b = cellScore(p, opp);
      sm += a; so += b;
      if (a >= 60) { var la = level(p, me); if (la >= 7) myFork = true; else if (la === 6) myF33 = true; if (la === 5 || la >= 7) my4++; }
      if (b >= 60) { var lb = level(p, opp); if (lb >= 8) opp3++; else if (lb >= 6) oppFork++; }
    }
    if (myFork) return 30000;
    if (myF33 && !opp3) return 15000;
    var s = (sm - so * 1.1) * 0.5;
    if (opp3 && !my4) s -= 3000;
    if (oppFork >= 2) s -= 2000;
    return s;
  }

  // ---------- alfa-beta ----------
  var TT = new Map();
  var searchWidth = 12;
  function negamax(me, depth, alpha, beta, ply) {
    if ((++nodes & 1023) === 0 && Date.now() > deadline) aborted = true;
    if (aborted) return 0;
    var g = genMoves(me, depth >= 3 ? searchWidth : Math.max(6, searchWidth - 4));
    if (g.win !== undefined) return WIN - ply;
    if (g.win2 !== undefined) return WIN - ply - 2;
    var moves;
    if (g.forced) {
      if (g.forced.length > 1) return -(WIN - ply - 1);
      moves = g.forced;
    } else moves = g.moves;
    if (!moves.length) return 0;
    if (depth <= 0 && !g.forced) return evaluate(me);
    var key = h1 >>> 0, e = TT.get(key), best = -Infinity, bestMove = moves[0], a0 = alpha;
    if (e && e.h2 === h2) {
      if (e.depth >= depth) {
        if (e.flag === 0) return e.score;
        if (e.flag === 1 && e.score >= beta) return e.score;
        if (e.flag === 2 && e.score <= alpha) return e.score;
      }
      var bi = moves.indexOf(e.best);
      if (bi > 0) { moves = moves.slice(); moves.splice(bi, 1); moves.unshift(e.best); }
    }
    var nd = g.forced ? depth : depth - 1; // vynucené tahy neubírají hloubku
    if (g.forced && ply > 30) nd = depth - 1;
    for (var i = 0; i < moves.length; i++) {
      var m = moves[i];
      place(m, me);
      var sc = -negamax(3 - me, nd, -beta, -alpha, ply + 1);
      remove(m);
      if (aborted) return 0;
      if (sc > best) { best = sc; bestMove = m; }
      if (sc > alpha) alpha = sc;
      if (alpha >= beta) break;
    }
    var flag = best <= a0 ? 2 : (best >= beta ? 1 : 0);
    if (TT.size > 400000) TT.clear();
    TT.set(key, { h2: h2, depth: depth, score: best, flag: flag, best: bestMove });
    return best;
  }

  function rootSearch(me, cands, maxDepth, ms) {
    deadline = Date.now() + ms; aborted = false; nodes = 0;
    TT = new Map();
    var bestMove = cands[0], bestScore = -Infinity, order = cands.slice(), reached = 0;
    for (var depth = 1; depth <= maxDepth; depth++) {
      var curBest = null, curScore = -Infinity, scores = {};
      var alpha = -Infinity;
      for (var i = 0; i < order.length; i++) {
        var m = order[i];
        place(m, me);
        var sc = -negamax(3 - me, depth - 1, -Infinity, -alpha, 1);
        remove(m);
        if (aborted) break;
        scores[m] = sc;
        if (sc > curScore) { curScore = sc; curBest = m; }
        if (sc > alpha) alpha = sc;
      }
      if (aborted) { if (curBest !== null && curScore > bestScore) { bestMove = curBest; bestScore = curScore; } break; }
      bestMove = curBest; bestScore = curScore; reached = depth;
      order.sort(function (a, b) { return (scores[b] === undefined ? -Infinity : scores[b]) - (scores[a] === undefined ? -Infinity : scores[a]); });
      if (curScore >= WIN - 50 || curScore <= -(WIN - 50)) break;
    }
    return { move: bestMove, score: bestScore, depth: reached };
  }

  // ---------- úrovně ----------
  var LEVELS = {
    1: { name: 'Začátečník' },
    2: { name: 'Lehký' },
    3: { name: 'Střední', ms: 300, depth: 4, width: 8, vcf: 8 },
    4: { name: 'Těžký', ms: 1000, depth: 6, width: 10, vcf: 14 },
    5: { name: 'Expert', ms: 2500, depth: 10, width: 12, vcf: 24, vct: 5, vctMs: 700 },
    6: { name: 'Neporazitelný', ms: 5000, depth: 14, width: 14, vcf: 40, vct: 7, vctMs: 1500, defVct: true }
  };

  function adj1(p) {
    var x = p % N, y = (p / N) | 0;
    for (var dy = -1; dy <= 1; dy++) for (var dx = -1; dx <= 1; dx++) {
      var xx = x + dx, yy = y + dy;
      if ((dx || dy) && xx >= 0 && yy >= 0 && xx < N && yy < N && board[yy * N + xx]) return true;
    }
    return false;
  }
  function pickRandom(arr) { return arr[(Math.random() * arr.length) | 0]; }

  function chooseMove(arr, me, lvl, exact) {
    setup(arr, exact);
    var opp = 3 - me, p;
    if (count === 0) return { move: 7 * N + 7, info: 'start' };
    var empties = 0; for (p = 0; p < NN; p++) if (!board[p]) empties++;
    if (!empties) return { move: -1 };
    // 1) vlastní pětka
    var g = genMoves(me, 40);
    if (g.win !== undefined) return { move: g.win, info: 'five' };
    var L = LEVELS[lvl] || LEVELS[3];
    // jednoduché úrovně
    if (lvl <= 2) return simpleMove(me, lvl, g);
    if (g.forced) return { move: g.forced[0], info: 'block' };
    if (g.win2 !== undefined) return { move: g.win2, info: 'open4' };
    searchWidth = L.width;
    var t0 = Date.now();
    // 2) vlastní VCF
    var v = findVCF(me, L.vcf, 300000, Math.min(1500, L.ms * 0.4));
    if (v && v.length) return { move: v[0], info: 'vcf', seq: v };
    // 3) vlastní VCT
    if (L.vct && !g.defend) {
      v = findVCT(me, L.vct, 150000, L.vctMs, 14);
      if (v && v.length) return { move: v[0], info: 'vct', seq: v };
    }
    // 4) kandidáti
    var cands = g.moves.slice();
    if (count <= 5 && !g.defend) { // v zahájení hraj těsně u kamenů
      var close = cands.filter(function (c) { return adj1(c); });
      if (close.length >= 3) cands = close;
    }
    // 5) obrana proti VCF soupeře
    var oppV = findVCF(opp, L.vcf, 300000, 800);
    if (oppV && oppV.length) {
      var set = {}, extra = [];
      cands.forEach(function (c) { set[c] = 1; });
      for (var i = 0; i < oppV.length; i++) if (!set[oppV[i]] && board[oppV[i]] === 0) { set[oppV[i]] = 1; extra.push(oppV[i]); }
      for (p = 0; p < NN; p++) if (!board[p] && near[p] && !set[p] && (isFour(p, me) || isFour(p, opp))) { set[p] = 1; extra.push(p); }
      cands = extra.concat(cands);
      var safe = [];
      for (i = 0; i < cands.length; i++) {
        place(cands[i], me);
        var r = findVCF(opp, L.vcf, 60000, 300);
        remove(cands[i]);
        if (!r) safe.push(cands[i]);
      }
      if (safe.length) cands = safe;
    } else if (L.defVct && !g.defend) {
      var oppT = findVCT(opp, L.vct - 1, 80000, 600, 14);
      if (oppT && oppT.length) {
        var set2 = {}, ex2 = [];
        cands.forEach(function (c) { set2[c] = 1; });
        oppT.forEach(function (c) { if (!set2[c] && board[c] === 0) { set2[c] = 1; ex2.push(c); } });
        cands = ex2.concat(cands);
        var safe2 = [], tEnd = Date.now() + 1800;
        for (i = 0; i < cands.length && Date.now() < tEnd; i++) {
          place(cands[i], me);
          var r2 = findVCF(opp, L.vcf, 40000, 200);
          if (!r2) r2 = findVCT(opp, L.vct - 1, 30000, 150, 12);
          remove(cands[i]);
          if (!r2) safe2.push(cands[i]);
        }
        if (safe2.length) cands = safe2;
      }
    }
    if (cands.length === 1) return { move: cands[0], info: 'only' };
    var left = Math.max(300, L.ms - (Date.now() - t0));
    var res = rootSearch(me, cands, L.depth, left);
    return { move: res.move, info: 'search', score: res.score, depth: res.depth };
  }

  function simpleMove(me, lvl, g) {
    var opp = 3 - me, p;
    if (g.forced) {
      var blockProb = lvl === 1 ? 0.55 : 1;
      if (Math.random() < blockProb) return { move: g.forced[0], info: 'block' };
    }
    if (g.win2 !== undefined && (lvl >= 2 || Math.random() < 0.6)) return { move: g.win2, info: 'open4' };
    var list = [];
    for (p = 0; p < NN; p++) {
      if (board[p] !== 0 || !near[p]) continue;
      var a = cellScore(p, me), b = cellScore(p, opp);
      list.push({ p: p, s: a + b * 0.9, la: level(p, me), lb: level(p, opp) });
    }
    if (!list.length) return { move: 7 * N + 7 };
    if (count <= 3) { var cl = list.filter(function (m) { return adj1(m.p); }); if (cl.length) list = cl; }
    if (lvl === 3) {
      // vlastní krátké VCF
      var v = findVCF(me, 10, 30000, 300);
      if (v && v.length) return { move: v[0], info: 'vcf' };
      // obrana proti otevřené trojce soupeře
      list.sort(function (x, y) { return y.s - x.s; });
      var top = list.filter(function (m) { return m.s >= list[0].s * 0.92; });
      return { move: pickRandom(top.slice(0, 2)).p, info: 'greedy' };
    }
    if (lvl === 2) {
      var hasOpp3 = list.some(function (m) { return m.lb >= 8; });
      if (hasOpp3 && Math.random() < 0.75) {
        var defs = list.filter(function (m) { return isFour(m.p, opp); });
        defs.sort(function (x, y) { return y.s - x.s; });
        if (defs.length) return { move: defs[0].p, info: 'def3' };
      }
      list.forEach(function (m) { m.s = m.s * (0.6 + Math.random() * 0.8); });
      list.sort(function (x, y) { return y.s - x.s; });
      return { move: list[0].p, info: 'easy' };
    }
    // lvl 1
    list.forEach(function (m) { m.s = m.s * (0.2 + Math.random() * 1.6) + Math.random() * 8; });
    list.sort(function (x, y) { return y.s - x.s; });
    return { move: list[Math.min(list.length - 1, (Math.random() * 3) | 0)].p, info: 'beginner' };
  }


  // náhodné vyvážené zahájení (3 kameny: X, O, X) – pro bota v roli zakládajícího
  function makeOpening(exact) {
    var best = null, bestAbs = Infinity;
    for (var t = 0; t < 10; t++) {
      var a = new Int8Array(NN), c = 7 * N + 7; a[c] = 1;
      var o, x;
      do { o = (7 + ((Math.random() * 5) | 0) - 2) * N + 7 + ((Math.random() * 5) | 0) - 2; } while (a[o]);
      a[o] = 2;
      do { x = (7 + ((Math.random() * 5) | 0) - 2) * N + 7 + ((Math.random() * 5) | 0) - 2; } while (a[x]);
      a[x] = 1;
      var sc = Math.abs(evalPosition(a, 2, exact, 60) + 0);
      if (sc < bestAbs) { bestAbs = sc; best = [c, o, x]; }
    }
    return best;
  }
  // swap2: přidání 2 kamenů (O a X) tak, aby pozice byla co nejvyrovnanější
  function balance2(arr, exact) {
    setup(arr, exact);
    var list = [];
    for (var p = 0; p < NN; p++) if (!board[p] && near[p]) list.push({ p: p, s: cellScore(p, 1) + cellScore(p, 2) + Math.random() * 5 });
    list.sort(function (a, b) { return b.s - a.s; });
    var cand = list.slice(0, 7).map(function (m) { return m.p; });
    var best = null, bestAbs = Infinity;
    for (var i = 0; i < cand.length; i++) for (var j = 0; j < cand.length; j++) {
      if (i === j) continue;
      var a = Int8Array.from(arr); a[cand[i]] = 2; a[cand[j]] = 1;
      var sc = Math.abs(evalPosition(a, 2, exact, 40));
      if (sc < bestAbs) { bestAbs = sc; best = [cand[i], cand[j]]; }
    }
    return best;
  }

  // ---------- pomocné API ----------
  function winLine(arr, p, exact) { // vrátí pole buněk výherní řady přes p nebo null
    var pl = arr[p]; if (!pl) return null;
    var x = p % N, y = (p / N) | 0;
    for (var d = 0; d < 4; d++) {
      var cells = [p];
      for (var s = -1; s <= 1; s += 2) {
        var xx = x + DX[d] * s, yy = y + DY[d] * s;
        while (xx >= 0 && yy >= 0 && xx < N && yy < N && arr[yy * N + xx] === pl) { cells.push(yy * N + xx); xx += DX[d] * s; yy += DY[d] * s; }
      }
      if (exact ? cells.length === 5 : cells.length >= 5) return cells;
    }
    return null;
  }

  // ohodnocení pozice pro výběr barvy (kladné = dobré pro toMove)
  function evalPosition(arr, toMove, exact, ms) {
    setup(arr, exact);
    searchWidth = 10;
    var g = genMoves(toMove, 10);
    if (g.win !== undefined || g.win2 !== undefined) return WIN;
    if (g.forced && g.forced.length > 1) return -WIN;
    var v = findVCF(toMove, 20, 50000, 200); if (v) return WIN;
    var cands = g.forced ? g.forced : g.moves;
    if (!cands.length) return 0;
    var r = rootSearch(toMove, cands, 4, ms || 300);
    return r.score;
  }
  function staticEval(arr, toMove, exact) { setup(arr, exact); return evaluate(toMove); }

  // kontrola úlohy: po tahu útočníka (útočník = att) – je to stále vynucená výhra?
  // mode: 'vcf' = tah musí být čtyřka, 'vct' = čtyřka nebo otevřená trojka
  function checkAttack(arr, move, att, exact, mode) {
    setup(arr, exact);
    var def = 3 - att;
    if (board[move] !== 0) return { ok: false, reason: 'occupied' };
    if (isFive(move, att)) return { ok: true, done: true };
    // musí reagovat na pětku soupeře?
    var df = fivePointsAll(def);
    if (df.length && df.indexOf(move) < 0) return { ok: false, reason: 'ignoredFour', refute: df[0] };
    place(move, att);
    var st = threatStatus(att, move);
    if (st.kind === 'win') { var fpw = fivePointsAround(move, att); return { ok: true, reply: fpw[0], win2: true }; }
    if (st.kind === 'none') return { ok: false, reason: 'noThreat' };
    if (mode === 'vcf' && st.kind !== 'four') return { ok: false, reason: 'notFour' };
    var defs = st.def, bestD = -1, bestLen = -1;
    if (st.kind === 'four' && isFive(defs[0], def)) return { ok: false, reason: 'defWins', refute: defs[0] };
    for (var i = 0; i < defs.length; i++) {
      var d = defs[i];
      place(d, def);
      var seq = (mode === 'vcf') ? findVCF(att, 30, 200000, 1500) : (findVCF(att, 30, 100000, 800) || findVCT(att, 6, 150000, 2000, 16));
      // obnov stav (findVCF/VCT vrací stav do původního)
      remove(d);
      if (!seq) { remove(move); return { ok: false, reason: 'refuted', refute: d }; }
      if (seq.length > bestLen) { bestLen = seq.length; bestD = d; }
    }
    remove(move);
    return { ok: true, reply: bestD };
  }
  // úloha na obranu: po tahu obránce (def) – má útočník stále výhru?
  function checkDefense(arr, move, def, exact, useVct) {
    setup(arr, exact);
    var att = 3 - def;
    if (board[move] !== 0) return { ok: false, reason: 'occupied' };
    if (isFive(move, def)) return { ok: true };
    place(move, def);
    var v = findVCF(att, 30, 200000, 1500);
    if (!v && useVct) v = findVCT(att, 6, 150000, 2500, 16);
    remove(move);
    if (v) return { ok: false, reason: 'stillWins', seq: v };
    return { ok: true };
  }
  function solve(arr, att, exact, mode) {
    setup(arr, exact);
    var v = findVCF(att, 30, 300000, 2000);
    if (!v && mode !== 'vcf') v = findVCT(att, 6, 200000, 3000, 16);
    return v;
  }
  function threatInfo(arr, exact) { // pro výukové zobrazení: hrozby na desce
    setup(arr, exact);
    var res = { 1: [], 2: [] };
    for (var p = 0; p < NN; p++) {
      if (board[p] || !near[p]) continue;
      for (var pl = 1; pl <= 2; pl++) { var l = level(p, pl); if (l >= 4) res[pl].push([p, l]); }
    }
    return res;
  }

  return {
    N: N, chooseMove: chooseMove, winLine: winLine, evalPosition: evalPosition, staticEval: staticEval,
    checkAttack: checkAttack, makeOpening: makeOpening, balance2: balance2, checkDefense: checkDefense, solve: solve, threatInfo: threatInfo,
    _setup: setup, _prm: PRM, _findVCF: findVCF, _findVCT: findVCT, _level: level, _board: board,
    _place: place, _remove: remove, _fivePointsAll: fivePointsAll, LEVELS: LEVELS
  };
}

function engineWorkerMain() {
  var E = EngineModule();
  self.onmessage = function (ev) {
    var m = ev.data, r;
    try {
      switch (m.cmd) {
        case 'move': r = E.chooseMove(m.board, m.me, m.level, m.exact); break;
        case 'eval': r = E.evalPosition(m.board, m.toMove, m.exact, m.ms); break;
        case 'static': r = E.staticEval(m.board, m.toMove, m.exact); break;
        case 'checkAttack': r = E.checkAttack(m.board, m.move, m.att, m.exact, m.mode); break;
        case 'checkDefense': r = E.checkDefense(m.board, m.move, m.def, m.exact, m.useVct); break;
        case 'solve': r = E.solve(m.board, m.att, m.exact, m.mode); break;
        case 'threats': r = E.threatInfo(m.board, m.exact); break;
        case 'opening': r = E.makeOpening(m.exact); break;
        case 'balance2': r = E.balance2(m.board, m.exact); break;
        case 'ping': r = 'pong'; break;
      }
      self.postMessage({ id: m.id, result: r });
    } catch (e) {
      self.postMessage({ id: m.id, error: String(e && e.stack || e) });
    }
  };
}

if (typeof module !== 'undefined' && module.exports) module.exports = EngineModule;
