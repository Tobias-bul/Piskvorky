/* Výukový kurz – lekce. Souřadnice: sloupce A–O (zleva), řádky 1–15 (zdola), střed = H8. */
(function () {
  var X = '<b class="x">✕</b>', O = '<b class="o">◯</b>';

  var BASE = [
    // ===================== KAPITOLA 1 =====================
    {
      id: 'zaklady-pravidla', chapter: '1 · Základy', title: 'Pravidla a soutěžní formát', desc: 'Deska, pětka, zahájení, proč swap',
      steps: [
        { title: 'Cíl hry', text: '<p>Hraje se na desce <b>15×15</b>. Vyhrává, kdo první složí <b>pět svých značek v řadě</b> – vodorovně, svisle nebo šikmo.</p><p>V aplikaci si můžeš zvolit pravidlo:</p><ul><li><b>Přesně 5</b> – šestka a víc nevyhrává (standard gomoku, používá se se Swap2).</li><li><b>5 a více</b> – vyhrává i delší řada (freestyle).</li></ul><p>Souřadnice: sloupce <b>A–O</b>, řádky <b>1–15</b> (zdola). Střed desky je <b>H8</b>.</p>',
          x: ['D8', 'E8', 'F8', 'G8', 'H8'], o: ['E7', 'F9', 'G7', 'H9'], line: ['D8', 'E8', 'F8', 'G8', 'H8'] },
        { title: 'Proč existuje swap', text: '<p>Začínající hráč má v piškvorkách obrovskou výhodu. V roce 1994 L. Victor Allis počítačově dokázal, že ve volném gomoku na 15×15 <b>začínající hráč při perfektní hře vždy vyhraje</b>.</p><p>Proto se na turnajích používají <b>zahajovací pravidla</b>, která výhodu vyrovnávají:</p><ul><li><b>Klasické</b> – ' + X + ' prostě začíná (vhodné na trénink taktiky).</li><li><b>Swap1</b> – první hráč položí 3 kameny (' + X + ' ' + O + ' ' + X + '), druhý si vybere barvu.</li><li><b>Swap2</b> – první položí 3 kameny; druhý může vzít ' + X + ', vzít ' + O + ', nebo položit další 2 kameny (' + O + ' + ' + X + ') a volbu barvy vrátit soupeři. Od roku 2009 je to standard mistrovství světa v gomoku.</li></ul><p>Smysl: zakládající se snaží postavit pozici <b>co nejvyrovnanější</b> – kdyby byla výhodná pro jednu barvu, soupeř si ji vezme.</p>' }
      ]
    },
    {
      id: 'zaklady-tvary', chapter: '1 · Základy', title: 'Tvary: dvojka, trojka, čtyřka', desc: 'Otevřené, zavřené a rozdělené tvary',
      steps: [
        { title: 'Čtyřky', text: '<p><b>Čtyřka</b> = čtyři kameny, které jedním tahem mohou dát pětku.</p><ul><li><b>Otevřená čtyřka</b> (nahoře): pětku lze dokončit na <b>dvou</b> místech → nelze ji ubránit. Kdo ji udělá, vyhrál.</li><li><b>Zavřená čtyřka</b> (uprostřed): jeden konec je blokovaný → jediné pole na pětku.</li><li><b>Rozdělená čtyřka</b> (dole): X X _ X X – díra uprostřed, jediné pole na pětku.</li></ul><p>Pole označená <b>5</b> jsou místa, kde vzniká pětka.</p>',
          x: ['E12', 'F12', 'G12', 'H12', 'E8', 'F8', 'G8', 'H8', 'E4', 'F4', 'H4', 'I4'], o: ['D8'],
          marks: { D12: '5', I12: '5', I8: '5', G4: '5' } },
        { title: 'Trojky', text: '<p><b>Trojka</b> = tvar, ze kterého jedním tahem vznikne čtyřka.</p><ul><li><b>Otevřená trojka</b> (nahoře): může se změnit v <b>otevřenou čtyřku</b> → soupeř musí okamžitě reagovat.</li><li><b>Rozdělená otevřená trojka</b> (uprostřed): X _ X X – stejně nebezpečná, doplnění díry dá otevřenou čtyřku.</li><li><b>Zavřená trojka</b> (dole): jeden konec blokovaný – dá jen zavřenou čtyřku, sama o sobě nehrozí.</li></ul><p>Pole <b>4</b> = vznik otevřené čtyřky.</p>',
          x: ['F12', 'G12', 'H12', 'E8', 'G8', 'H8', 'E4', 'F4', 'G4'], o: ['D4'],
          marks: { E12: '4', I12: '4', F8: '4' } },
        { title: 'Dvojky a potenciál', text: '<p><b>Dvojka</b> = dva kameny, ze kterých může vzniknout trojka. Otevřené dvojky jsou „suroviny“ pro útok – čím víc jich máš v různých směrech, tím víc budoucích hrozeb.</p><p>Důležité: kámen, který je zapojený do <b>více směrů</b> (vodorovně, svisle, dvě úhlopříčky), má větší hodnotu. Silní hráči staví kameny tak, aby každý pracoval aspoň ve dvou směrech.</p>',
          x: ['G8', 'H8', 'H9', 'I10'], o: ['G9', 'I8'] },
        { title: 'Úloha: dokonči útok', text: '<p>' + X + ' má otevřenou trojku. Zahraj tah, který vede k jisté výhře.</p>',
          x: ['G8', 'H8', 'I8', 'H10'], o: ['H7', 'I9', 'G10'], puzzle: { kind: 'win', mode: 'vct', toMove: 1, best: ['F8', 'J8'], explain: 'Otevřená čtyřka má dvě pole na pětku – soupeř zablokuje jen jedno.' } }
      ]
    },
    {
      id: 'zaklady-tempo', chapter: '1 · Základy', title: 'Hrozby, tempo a iniciativa', desc: 'Kdo útočí, ten diktuje',
      steps: [
        { title: 'Síla hrozeb', text: '<p>Hrozby podle naléhavosti:</p><ul><li><b>Pětka</b> – konec hry.</li><li><b>Čtyřka</b> – soupeř má <b>jedinou</b> odpověď (zablokovat), jinak prohraje. Absolutní hrozba.</li><li><b>Otevřená trojka</b> – soupeř musí reagovat, ale má obvykle <b>3–4 obranná pole</b>, nebo může odpovědět vlastní čtyřkou.</li></ul><p><b>Tempo / iniciativa</b>: kdo hraje hrozby, nutí soupeře reagovat a soupeř nestíhá stavět vlastní útok. Většina partií se rozhoduje tím, kdo má iniciativu.</p>' },
        { title: 'Priority každého tahu', text: '<ol><li>Můžu udělat pětku? → udělej ji.</li><li>Má soupeř čtyřku? → zablokuj (nebo vyhraj).</li><li>Můžu udělat otevřenou čtyřku nebo vidličku (4-4, 4-3)? → udělej.</li><li>Má soupeř otevřenou trojku? → braň (nebo protiútok čtyřkami, který vede k výhře).</li><li>Mám vynucenou výhru čtyřkami (VCF)? → hraj ji.</li><li>Má soupeř VCF? → musíš ho zastavit už teď.</li><li>Mám výhru hrozbami (VCT)? Má ji soupeř?</li><li>Jinak: poziční tah – rozvoj vlastního potenciálu + rušení soupeřova.</li></ol><p>Tenhle seznam budeme v dalších lekcích rozvíjet.</p>' },
        { title: 'Úloha: rozdělená trojka', text: '<p>' + X + ' má rozdělenou trojku. Najdi vítězný tah.</p>',
          x: ['F8', 'G8', 'I8', 'G10'], o: ['G7', 'H9', 'F10'], puzzle: { kind: 'win', mode: 'vct', toMove: 1, best: ['H8'], explain: 'Doplněním díry H8 vzniká otevřená čtyřka F8–I8.' } }
      ]
    },
    // ===================== KAPITOLA 2 =====================
    {
      id: 'vidlicka-43', chapter: '2 · Vidličky', title: 'Vidlička 4-3', desc: 'Nejčastější vítězný úder',
      steps: [
        { title: 'Co je 4-3', text: '<p><b>Vidlička 4-3</b> = jedním tahem vytvoříš <b>čtyřku</b> a zároveň <b>otevřenou trojku</b>. Soupeř musí zablokovat čtyřku, a tvoje trojka se pak změní v otevřenou čtyřku.</p><p>Na diagramu tah <b>A</b> (I8) vytvoří zavřenou čtyřku F8–I8 a otevřenou trojku I6–I8.</p><p>4-3 je hlavní vítězná zbraň – je povolená i v renju.</p>',
          x: ['F8', 'G8', 'H8', 'I6', 'I7'], o: ['E8', 'H9', 'J6'], marks: { I8: 'A' } },
        { title: 'Úloha 1', text: '<p>Najdi vidličku 4-3.</p>',
          x: ['F8', 'G8', 'H8', 'I6', 'I7'], o: ['E8', 'H9', 'J6'], puzzle: { kind: 'win', mode: 'vct', toMove: 1, best: ['I8'], explain: 'I8 = čtyřka F8–I8 + otevřená trojka I6–I8.' } },
        { title: 'Úloha 2', text: '<p>Tentokrát je vidlička šikmo. Najdi ji.</p>',
          x: ['G7', 'H8', 'I9', 'J7', 'J8'], o: ['F6', 'H9', 'J6', 'K10'], puzzle: { kind: 'win', mode: 'vct', toMove: 1, best: ['J10'], explain: 'J10 = zavřená čtyřka G7–J10 šikmo + otevřená (rozdělená) trojka J7–J10.' } }
      ]
    },
    {
      id: 'vidlicka-44', chapter: '2 · Vidličky', title: 'Vidlička 4-4', desc: 'Dvě čtyřky naráz – i v jedné řadě',
      steps: [
        { title: 'Dvojitá čtyřka', text: '<p><b>4-4</b> = jeden tah vytvoří dvě čtyřky. Soupeř zablokuje jen jednu.</p><p>Na diagramu tah <b>A</b> (I8) vytvoří čtyřku vodorovně (F8–I8) i svisle (I8–I11).</p>',
          x: ['F8', 'G8', 'H8', 'I9', 'I10', 'I11'], o: ['E8', 'I12', 'H10', 'J9'], marks: { I8: 'A' } },
        { title: 'Úloha 1', text: '<p>Najdi 4-4.</p>',
          x: ['F8', 'G8', 'H8', 'I9', 'I10', 'I11'], o: ['E8', 'I12', 'H10', 'J9'], puzzle: { kind: 'win', mode: 'vcf', toMove: 1 } },
        { title: '4-4 v jedné řadě', text: '<p>Zrádný tvar: <b>X _ X X X _ X</b>. Dvě čtyřky v jedné linii – pětku lze udělat na dvou různých místech. Snadno se přehlédne!</p><p>Úloha: najdi tah, který vytvoří dvě čtyřky v jedné řadě.</p>',
          x: ['E8', 'G8', 'H8', 'K8'], o: ['D8', 'L8', 'G9', 'H7'], puzzle: { kind: 'win', mode: 'vcf', toMove: 1, explain: 'I8: pětka hrozí na F8 (E–I) i na J8 (G–K).' } }
      ]
    },
    {
      id: 'vidlicka-33', chapter: '2 · Vidličky', title: 'Vidlička 3-3', desc: 'Dvě otevřené trojky',
      steps: [
        { title: 'Dvojitá trojka', text: '<p><b>3-3</b> = tah vytvoří dvě otevřené trojky. Soupeř zablokuje jednu, z druhé uděláš otevřenou čtyřku.</p><p>Pozor: soupeř se může bránit <b>čtyřkami</b> – pokud má zavřené trojky, může jimi získat tempo a některou trojku zablokovat „mimochodem“. Proto 3-3 je slabší než 4-3.</p><p>V gomoku je 3-3 povolená pro oba. (V renju ji černý hrát nesmí.)</p>',
          x: ['G8', 'H8', 'I9', 'I10'], o: ['G7', 'H9', 'J10'], marks: { I8: 'A' } },
        { title: 'Úloha', text: '<p>Najdi 3-3.</p>',
          x: ['G8', 'H8', 'I9', 'I10'], o: ['G7', 'H9', 'J10'], puzzle: { kind: 'win', mode: 'vct', toMove: 1, best: ['I8'] } }
      ]
    },
    // ===================== KAPITOLA 3 =====================
    {
      id: 'vcf', chapter: '3 · Vynucené série', title: 'VCF – výhra čtyřkami', desc: 'Victory by Continuous Fours',
      steps: [
        { title: 'Princip VCF', text: '<p><b>VCF</b> (Victory by Continuous Fours) = série tahů, kde <b>každý tah je čtyřka</b>. Soupeř má vždy jen jednu odpověď, takže sérii můžeš spočítat úplně přesně – je to „matematická“ výhra.</p><p>Postup výpočtu:</p><ol><li>Najdi všechny své možné čtyřky.</li><li>Pro každou si představ vynucený blok soupeře.</li><li>Hledej, zda tvoje čtyřka + jeho blok nevytvoří novou čtyřku, 4-4 nebo 4-3.</li><li>Pozor: soupeřův blok mu může dát vlastní čtyřku – pak musíš reagovat ty a série se může přerušit!</li></ol><p>Na turnaji: <b>před každým tahem zkontroluj své VCF i soupeřovo.</b></p>' },
        { title: 'Úloha 1', text: '<p>Vyhraj jen čtyřkami. Pozice je z partie – hledej, kde se kříží tvoje linie.</p>', gen: 'vcf', i: 0, puzzle: { kind: 'win', mode: 'vcf' } },
        { title: 'Úloha 2', text: '<p>Vyhraj jen čtyřkami. Nejdřív si sérii spočítej v hlavě, pak hraj.</p>', gen: 'vcf', i: 1, puzzle: { kind: 'win', mode: 'vcf' } }
      ]
    },
    {
      id: 'vct', chapter: '3 · Vynucené série', title: 'VCT – výhra hrozbami', desc: 'Čtyřky i otevřené trojky',
      steps: [
        { title: 'Princip VCT', text: '<p><b>VCT</b> (Victory by Continuous Threats) = každý tah je hrozba: čtyřka <b>nebo otevřená trojka</b>. Soupeř má po trojce víc možností obrany (oba konce, vzdálené body, protiútok čtyřkou), takže musíš počítat <b>všechny větve</b>.</p><p>Typický průběh: několika trojkami „nahoníš“ soupeřovy kameny tam, kde ti nevadí, a pak sérii zakončíš VCF.</p><p>Než zahraješ trojku, ověř si, že soupeř <b>nemá vlastní VCF</b> – trojka mu dává čas, a pokud má výhru čtyřkami, trojku prostě ignoruje.</p>' },
        { title: 'Úloha 1', text: '<p>Vyhraj sérií hrozeb (čtyřky a otevřené trojky).</p>', gen: 'vct', i: 0, puzzle: { kind: 'win', mode: 'vct' } },
        { title: 'Úloha 2', text: '<p>Vyhraj sérií hrozeb.</p>', gen: 'vct', i: 1, puzzle: { kind: 'win', mode: 'vct' } }
      ]
    },
    // ===================== KAPITOLA 4 =====================
    {
      id: 'obrana-trojka', chapter: '4 · Obrana', title: 'Obrana proti otevřené trojce', desc: 'Který konec blokovat',
      steps: [
        { title: 'Obranná pole', text: '<p>Proti otevřené trojce ' + O + ' (G8–I8) máš obvykle <b>4 obranná pole</b>: oba sousední konce (<b>A</b>, <b>B</b>) a vzdálené konce (<b>a</b>, <b>b</b>). Vzdálený blok dovolí soupeři jen zavřenou čtyřku.</p><p>Jak vybrat:</p><ul><li>Vyber pole, které <b>zároveň pomáhá tobě</b> (staví tvoji dvojku/trojku).</li><li>Blokuj na straně, kde má soupeř <b>víc dalších kamenů</b> (kde by vznikla vidlička).</li><li>U rozdělené trojky (O_OO) je nejsilnější obrana obvykle <b>do díry</b>.</li></ul>',
          x: ['F9', 'J7', 'G10'], o: ['G8', 'H8', 'I8', 'I9'], marks: { F8: 'A', J8: 'B', E8: 'a', K8: 'b' } },
        { title: 'Úloha', text: '<p>' + O + ' má otevřenou trojku a další kameny kolem. Najdi obranu, po které ' + O + ' nemá vynucenou výhru.</p>',
          x: ['F9', 'G10', 'K9', 'J10'], o: ['G8', 'H8', 'I8', 'I9', 'J7'], puzzle: { kind: 'defend', mode: 'vct', toMove: 1, explain: 'Na straně I–J má ' + O + ' další kameny (I9, J7), tam hrozí vidlička. Blok musí být na té nebezpečné straně.' } }
      ]
    },
    {
      id: 'obrana-protiutok', chapter: '4 · Obrana', title: 'Obrana protiútokem', desc: 'Čtyřka jako obranný tah',
      steps: [
        { title: 'Protiútok', text: '<p>Na hrozbu nemusíš vždy odpovědět pasivním blokem. Pokud máš <b>vlastní čtyřku</b>, která zároveň blokuje soupeřovu linii, získáš tempo „zadarmo“.</p><p>Ještě silnější je, když máš vlastní <b>VCF</b> – pak soupeřovu trojku ignoruješ a vyhraješ dřív.</p><p>Obecné pravidlo obrany: <b>nejlepší obranný tah je ten, který zároveň útočí</b>. Pasivní obránce dřív nebo později prohraje, protože útočník si „nahrává“ další hrozby.</p>' },
        { title: 'Prevence', text: '<p>Dobrá obrana začíná dřív, než soupeř zahraje trojku:</p><ul><li>Sleduj místa, kde se kříží dvě soupeřovy linie – <b>vidličkové body</b>. Obsaď je dřív než on.</li><li>Kontroluj, jestli soupeř po tvém tahu nemá VCF (série čtyřek, kterou nelze zastavit).</li><li>Když nevíš, kam hrát, hraj tah, který ruší soupeřův nejlepší tvar a zároveň stavíš svůj.</li></ul><p>Zapni si v menu hry (⋯) <b>Zobrazovat hrozby</b> – barevně uvidíš pole, kde vznikají čtyřky a vidličky.</p>' }
      ]
    },
    // ===================== KAPITOLA 5 =====================
    {
      id: 'strategie-tvar', chapter: '5 · Strategie', title: 'Tvar, potenciál a skryté hrozby', desc: 'Jak stavět útok dřív, než je vidět',
      steps: [
        { title: 'Dobrý tvar', text: '<ul><li><b>Kompaktnost</b>: kameny blízko sebe (vzdálenost 1–2) se navzájem podporují. Kameny rozházené daleko od boje jsou ztracené tempo.</li><li><b>Více směrů</b>: každý kámen by měl patřit do 2+ linií. Kámen na křížení linií je „vidličkový“ kámen.</li><li><b>Úhlopříčky</b>: diagonální spojení soupeři hůř blokují a často přehlédnou.</li><li><b>Dál od okraje</b>: u okraje mají linie méně prostoru.</li></ul>' },
        { title: 'Skryté hrozby a příprava', text: '<p>Silní hráči hrají tahy, které <b>nejsou hned hrozbou</b>, ale připravují VCF nebo VCT na další tah. Soupeř pak musí reagovat na neviditelnou hrozbu – a když ji nepozná, prohraje.</p><ul><li>Hledej tah, po kterém by sis v dalším tahu mohl dovolit VCF. Pokud soupeř nemá čím odpovědět (žádné vlastní čtyřky), je to často rozhodující.</li><li>Nejlepší je tah, který dělá <b>dvě různé přípravy najednou</b> – soupeř zastaví jen jednu.</li><li>Opačně: hrozba, kterou soupeř zablokuje tahem, který mu pomáhá, je špatná hrozba. Neplýtvej čtyřkami bezdůvodně – každá vyhozená čtyřka je ztracený zdroj budoucího VCF.</li></ul>' },
        { title: 'Kontrolní postup (checklist)', text: '<p>Před <b>každým</b> tahem v soutěži:</p><ol><li>Co soupeř posledním tahem chtěl? Jaké linie posílil?</li><li>Má soupeř čtyřku, otevřenou trojku, VCF? (Projdi všechny jeho možné čtyřky.)</li><li>Mám já VCF / VCT?</li><li>Kandidátní tahy: 2–4 nejlepší. U každého: co odpoví soupeř?</li><li>Vyber tah, který <b>útočí a brání zároveň</b>.</li></ol><p>Tento postup trénuj s botem na úrovni Těžký/Expert se zapnutým zobrazováním hrozeb, později bez nich.</p>' }
      ]
    },
    // ===================== KAPITOLA 6 =====================
    {
      id: 'zahajeni', chapter: '6 · Zahájení a Swap', title: 'Zahájení: přímé a nepřímé', desc: 'Prvních pár tahů',
      steps: [
        { title: 'Přímé a nepřímé', text: '<p>Po prvním kameni ' + X + ' ve středu (H8) hraje ' + O + ' druhý kámen:</p><ul><li><b>Přímo</b> (vedle, např. H9) – „přímé zahájení“.</li><li><b>Šikmo</b> (např. I9) – „nepřímé zahájení“.</li></ul><p>V renju existuje 26 standardních zahájení (13 přímých a 13 nepřímých) podle pozice třetího kamene. Nejsilnější pro černého jsou <b>Kagetsu</b> (přímé) a <b>Uragetsu</b> (nepřímé) – na diagramu je Kagetsu (třetí kámen <b>3</b>).</p><p>V gomoku bez omezení je výhoda začínajícího ještě větší – proto swap.</p>',
          x: ['H8', 'I9'], o: ['H9'], marks: { H8: '1', H9: '2', I9: '3' } },
        { title: 'Principy zahájení', text: '<ul><li>První kameny hraj u středu – víc prostoru ve všech směrech.</li><li>' + O + ' (druhý hráč) by se měl držet těsně u ' + X + ' a rušit jeho tvary; vzdálené tahy dávají ' + X + ' volnost.</li><li>' + X + ' by měl rychle stavět kameny ve více směrech a hledat první otevřenou trojku s podporou.</li><li>Počítej tempa: kdo první vytvoří dvě nezávislé hrozby, obvykle vyhrává.</li></ul>' }
      ]
    },
    {
      id: 'swap-strategie', chapter: '6 · Zahájení a Swap', title: 'Strategie Swap1 a Swap2', desc: 'Jak zakládat a jak vybírat barvu',
      steps: [
        { title: 'Když zakládáš', text: '<ul><li>Cíl: pozice, ve které je <b>těžké poznat</b>, kdo je lepší. Ideálně taková, kterou znáš lépe než soupeř.</li><li>Nestav pozici, kde ' + X + ' má okamžitě silný tvar (soupeř vezme ' + X + '), ani kde je ' + X + ' rozházený (soupeř vezme ' + O + ').</li><li>Připrav si 3–5 vlastních zahájení a nauč se je hrát za obě barvy. V aplikaci zvol Swap2, roli „Já zakládám“ a sleduj, co si bot vybere.</li></ul>' },
        { title: 'Když vybíráš', text: '<ul><li>Po 3 kamenech je na tahu ' + O + '. Zhodnoť: má ' + X + ' silný tvar? Pak ber ' + X + '. Je ' + X + ' slabý a ' + O + ' může hned rušit a stavět? Ber ' + O + '.</li><li><b>Swap2 – položit 2 kameny</b>: když si nejsi jistý, přidáš ' + O + ' + ' + X + ' a rozhodnutí je zase na soupeři. Tvoje 2 kameny by měly pozici <b>znovu vyrovnat</b>, ideálně do typu pozice, který znáš.</li><li>Vybírej barvu podle svého stylu: útočník bere často ' + X + ', dobrý obránce ' + O + '.</li></ul>' },
        { title: 'Tréninkový plán', text: '<ol><li>Denně 10–15 minut úlohy (lekce 3 a 4 a tréninkové sady níže).</li><li>Partie proti botu Těžký/Expert se Swap2 – střídej roli zakládajícího a vybírajícího.</li><li>Po prohře si projdi partii (zapni čísla tahů) a najdi moment, kdy soupeř získal iniciativu.</li><li>Ke konci tréninku hraj na úrovni Neporazitelný – učíš se bránit pod tlakem.</li></ol>' }
      ]
    }
  ];

  function puzzleLessons(P) {
    var res = [];
    function mk(id, title, desc, list, kind, mode, text, max) {
      if (!list || list.length < 3) return;
      var steps = list.slice(0, max || 12).map(function (q, i) {
        return { title: 'Úloha ' + (i + 1) + ' / ' + Math.min(list.length, max || 12), text: text(q), x: q.x, o: q.o, puzzle: { kind: kind, mode: mode, toMove: q.s } };
      });
      res.push({ id: id, chapter: '7 · Tréninkové sady', title: title, desc: desc, steps: steps });
    }
    var bylen = function (a, b) { return (a.len || 0) - (b.len || 0); };
    mk('t-43', 'Najdi vidličku', 'Pozice z partií – 4-3', P.f43, 'win', 'vct', function (q) { return '<p>Pozice z partie. Na tahu je ' + (q.s === 1 ? X : O) + '. Najdi vítězný úder.</p>'; });
    mk('t-vcf', 'VCF trénink', 'Výhra čtyřkami, od kratších', (P.vcf || []).slice(2), 'win', 'vcf', function (q) { return '<p>Na tahu je ' + (q.s === 1 ? X : O) + '. Vyhraj <b>jen čtyřkami</b>' + (q.len ? ' (série cca ' + q.len + ' tahů)' : '') + '.</p>'; }, 15);
    mk('t-vct', 'VCT trénink', 'Výhra hrozbami', (P.vct || []).slice(2), 'win', 'vct', function (q) { return '<p>Na tahu je ' + (q.s === 1 ? X : O) + '. Vyhraj sérií hrozeb (čtyřky a otevřené trojky).</p>'; }, 15);
    mk('t-def', 'Obrana trénink', 'Najdi jedinou obranu', P.def, 'defend', 'vct', function (q) { return '<p>Na tahu je ' + (q.s === 1 ? X : O) + '. Soupeř hrozí vynucenou výhrou. Najdi obranu' + (q.acc && q.acc.length === 1 ? ' – existuje jen <b>jedna</b>.' : ' (je jich jen ' + (q.acc ? q.acc.length : 'pár') + ').') + '</p>'; }, 15);
    return res;
  }

  function resolveGen(list, P) {
    return list.map(function (L) {
      var steps = L.steps.map(function (st) {
        if (!st.gen) return st;
        var q = (P[st.gen] || [])[st.i];
        if (!q) return null;
        var c = Object.assign({}, st, { x: q.x, o: q.o });
        c.puzzle = Object.assign({}, st.puzzle, { toMove: q.s });
        c.text = (st.text || '') + '<p>Na tahu je ' + (q.s === 1 ? X : O) + '.</p>';
        return c;
      }).filter(Boolean);
      return Object.assign({}, L, { steps: steps });
    });
  }
  var root = typeof window !== 'undefined' ? window : global;
  root.buildLessons = function (P) { P = P || {}; return resolveGen(BASE, P).concat(puzzleLessons(P)); };
  if (typeof module !== 'undefined') module.exports = { BASE: BASE, build: root.buildLessons };
})();
